package com.testlink;

import java.io.FileWriter;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

public class Excel2Xml {

	public Excel2Xml() {

	}

	static int stepNum = 1;// 用例步骤

	static String filePath = "始发地航空站0228用例 - 副本.xlsx";

	static String testLinkXmlFile = "foo1.xml";

	public static void main(String[] args) {
		writeXmlFile(testLinkXmlFile);
	}

	/**
	 * 写出testlink xml文件
	 */
	public static void writeXmlFile(String testLinkXmlFile) {
		try {
			OutputFormat format = OutputFormat.createPrettyPrint();
			FileWriter out = new FileWriter(testLinkXmlFile);
			Document document = parseTestCase(filePath);
			XMLWriter writer2File;
			writer2File = new XMLWriter(out, format);
			writer2File.write(document);
			out.close();

			// 美化文档格式输出到System.out

			XMLWriter writer;
			writer = new XMLWriter(System.out, format);
			writer.write(document);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param filePath
	 *            excel测试用例路径
	 * @return xml Document对象
	 */
	@SuppressWarnings("deprecation")
	public static Document parseTestCase(String filePath) {

		// DataFormatter formatter = new DataFormatter();
		Workbook workbook = ExcelUtil.readExcel(filePath);// 读取Excel文件
		Sheet caseSheet = workbook.getSheetAt(0);// 获取解析用例的表格

		Document document = DocumentHelper.createDocument();
		// document.setXMLEncoding("utf-8");// 设置xml头条的Encoding
		// 设置xml根节点属性
		Element root = document.addElement("testsuite");
		root.addAttribute("name", "");// 添加name属性

		// 设置xml头信息
		Element nodeOrder = root.addElement("node_order");

		nodeOrder.addCDATA("");

		Element details = root.addElement("details");

		details.addCDATA("");

		System.out.println("最大行数为:" + caseSheet.getLastRowNum());

		Element testsuiteChildNodes = null;
		Element testCase = null;
		Element steps = null;
		// 从第二行开始读取,遍历整个用例表

		for (int pathRow = 1; pathRow < caseSheet.getLastRowNum(); pathRow++) {
			Element parent = root; // 将parent设置为根目录
			System.out.println(
					"==========================当前为第" + pathRow + "次循环===========================================");
			Row currentRow = caseSheet.getRow(pathRow);
			Cell testsuiteCell = currentRow.getCell(0);// 获取案例路径

			// 获取testsuite的值
			if (testsuiteCell.getCellType() == Cell.CELL_TYPE_STRING) {

				String path_str = testsuiteCell.getStringCellValue();

				System.out.println(testsuiteCell.getRichStringCellValue().getString());

				String[] path = path_str.split("/");

				for (String str : path) {
					System.out.println("str====================" + str);
					String dirName = str;
					testsuiteChildNodes = parent.addElement("testsuite").addAttribute("name", dirName);
					testsuiteChildNodes.addElement("node_order").addCDATA("");
					testsuiteChildNodes.addElement("details").addCDATA("");
					parent = testsuiteChildNodes;// 替换父节点
				}

			}

			// 获取用例名称

			Cell caseCell = currentRow.getCell(1);// 获取用例名称

			System.out.println("第" + pathRow + "次循环========================================用例名称为:"
					+ caseCell.getStringCellValue());

			Cell summaryCell = currentRow.getCell(2);// 获取摘要

			System.out.println("第" + pathRow + "次循环========================================摘要名称为:"
					+ summaryCell.getStringCellValue());

			Cell stepCell = currentRow.getCell(5);// 获取步骤

			// String step = stepCell.getStringCellValue();
			System.out.println("步骤为:^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" + stepCell.getStringCellValue());
			// 设置预期结果
			Cell expectedresultsCell = currentRow.getCell(6);
			// String expectedresults = expectedresultsCell.getStringCellValue();
			System.out.println("期望为:^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" + expectedresultsCell.getStringCellValue());

			String caseName = null;// 用例名称
			if (caseCell.getCellType() == Cell.CELL_TYPE_STRING && caseCell.getCellType() != Cell.CELL_TYPE_BLANK) {
				stepNum = 1;
				if (caseCell.getStringCellValue() != null) {

					caseName = caseCell.getStringCellValue();

					testCase = testsuiteChildNodes.addElement("testcase").addAttribute("name", caseName);
					testCase.addElement("node_order").addCDATA("");

					String summaryName = null;
					if (summaryCell.getCellType() == Cell.CELL_TYPE_STRING
							&& summaryCell.getCellType() != Cell.CELL_TYPE_BLANK) {
						summaryName = summaryCell.getStringCellValue();
						testCase.addElement("summary").addCDATA("<p>" + summaryName + "<p/>");
					}

					// 获取优先级
					Cell importanceCell = currentRow.getCell(3);// 获取优先级
					String importance = null;

					if (importanceCell.getCellType() == Cell.CELL_TYPE_STRING
							&& importanceCell.getCellType() != Cell.CELL_TYPE_BLANK) {
						importance = importanceCell.getStringCellValue();
						testCase.addElement("importance").addCDATA(importance);
					}

					// 获取前提，前提不为空
					Cell preconditionsCell = currentRow.getCell(4);// 获取前提
					String preconditions = null;
					if (preconditionsCell.getCellType() == Cell.CELL_TYPE_STRING
							&& preconditionsCell.getCellType() != Cell.CELL_TYPE_BLANK) {
						preconditions = preconditionsCell.getStringCellValue();

						testCase.addElement("preconditions").addCDATA("<p>" + preconditions + "<p/>");
					}
					// 前提为空的 情况
					if (preconditionsCell.getCellType() == Cell.CELL_TYPE_BLANK) {

						testCase.addElement("preconditions").addCDATA("<p><p/>");
					}

					// 添加步骤标签
					steps = testCase.addElement("steps");

				}

				// meihuo

				// 获取步骤
			}

			if (caseName == null && caseCell.getCellType() == Cell.CELL_TYPE_BLANK) {

				stepNum++;

				System.out.println("================================stepNum的值为:" + stepNum);

			}

			String step = null;

			if (stepCell.getCellType() == Cell.CELL_TYPE_STRING) {

				// 获取步骤中的描述
				step = stepCell.getStringCellValue();

				System.out.println("########################步骤为:" + step);

			}

			String expectedresults = null;
			if (expectedresultsCell.getCellType() == Cell.CELL_TYPE_STRING) {
				expectedresults = expectedresultsCell.getStringCellValue();
			}

			// // 获取步骤中的描述

			Element actionStep = steps.addElement("step");

			// // 设置步骤顺序

			actionStep.addElement("step_number").addCDATA(Integer.toString(stepNum));

			System.out.println("*************************************" + stepNum);
			System.out.println("当前用例:<" + caseName + "> 步骤数为" + stepNum);
			// 设置步骤
			actionStep.addElement("actions").addCDATA("<p>" + step + "<p/>");

			// 设置预期结果
			// Cell expectedresultsCell = currentRow.getCell(6);

			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$期望结果为:" + expectedresults);
			actionStep.addElement("expectedresults").addCDATA("<p>" + expectedresults + "<p/>");
			// }
		}
		return document;
	}

}
