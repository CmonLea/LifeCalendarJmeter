package com.testlink;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Excel2XMLUI extends JFrame {

	public static void main(String[] args) {
		new Excel2XMLUI();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 9134604994013111325L;

	public Excel2XMLUI() {
		JLabel exLabel = new JLabel("选择Excel源文件");
		JTextField excelFilePath = new JTextField(50);
		JButton excelButton = new JButton("...");
		JLabel xmlLabel = new JLabel("选择Xml目标文件");
		JTextField xmlFilePath = new JTextField(50);
		JButton xmlButton = new JButton("...");

		JButton covertButton = new JButton("开始转换");

		JPanel jPanel = new JPanel();

		jPanel.add(exLabel);
		jPanel.add(excelFilePath);
		jPanel.add(excelButton);

		jPanel.add(xmlLabel);
		jPanel.add(xmlFilePath);
		jPanel.add(xmlButton);

		jPanel.add(covertButton);

		Container container = getContentPane(); // container.add(jPanel);

		Box excelLabelBox = Box.createHorizontalBox();// 创建一个水平箱容器
		container.add(excelLabelBox, BorderLayout.NORTH);// 添加到窗体中
		excelLabelBox.add(Box.createHorizontalStrut(5));// 添加一个5像素宽的水平支柱

		excelLabelBox.add(exLabel);// 添加到水平箱容器中

		Box excelbox = Box.createVerticalBox();// 创建一个垂直箱容器

		excelbox.add(Box.createVerticalStrut(5));// 添加一个5像素高的垂直支柱
		Box excelFileBox = Box.createHorizontalBox();// 创建一个水平箱容器

		container.add(excelbox, BorderLayout.EAST);// 添加到窗体中

		excelFileBox.add(excelFilePath);
		excelFileBox.add(Box.createHorizontalStrut(5));// 添加一个5像素宽的水平支柱
		excelFileBox.add(excelButton);

		container.add(excelFileBox, BorderLayout.CENTER);// 添加到窗体中

		
		Box box = Box.createVerticalBox();// 创建一个垂直箱容器
		getContentPane().add(box, BorderLayout.CENTER);// 添加到窗体中
		box.add(Box.createVerticalStrut(5));// 添加一个5像素高的垂直支柱
		
		Box xmlLabelBox = Box.createHorizontalBox();// 创建一个水平箱容器
		container.add(xmlLabelBox, BorderLayout.NORTH);// 添加到窗体中
		xmlLabelBox.add(Box.createHorizontalStrut(5));// 添加一个5像素宽的水平支柱

		xmlLabelBox.add(exLabel);// 添加到水平箱容器中

		Box xmlbox = Box.createVerticalBox();// 创建一个垂直箱容器

		xmlbox.add(Box.createVerticalStrut(5));// 添加一个5像素高的垂直支柱
		Box xmlFileBox = Box.createHorizontalBox();// 创建一个水平箱容器

		container.add(xmlbox, BorderLayout.EAST);// 添加到窗体中

		xmlFileBox.add(xmlFilePath);
		xmlFileBox.add(Box.createHorizontalStrut(5));// 添加一个5像素宽的水平支柱
		xmlFileBox.add(xmlButton);

		container.add(xmlFileBox, BorderLayout.CENTER);// 添加到窗体中

//		Box XmlLabelbox = Box.createVerticalBox();// 创建一个垂直箱容器
//
//		container.add(XmlLabelbox, BorderLayout.CENTER);
//		XmlLabelbox.add(Box.createVerticalStrut(5));// 添加一个5像素高的垂直支柱
//
//		Box xmlBox = Box.createHorizontalBox();// 创建一个水平箱容器
//
//		XmlLabelbox.add(xmlLabel);
//		XmlLabelbox.add(Box.createVerticalStrut(5));// 添加一个5像素高的垂直支柱
//		XmlLabelbox.add(xmlFilePath);
//		XmlLabelbox.add(xmlButton);

		// container.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setSize(500, 300);
		setVisible(true);

	}

}
