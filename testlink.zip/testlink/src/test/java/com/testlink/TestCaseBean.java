package com.testlink;

public class TestCaseBean {

	String testcasePath=null;//测试案例路径
	String testcaseName=null;//测试案例名称
	String testDescription=null;//测试案例描述
	String testPriority=null;//测试案例优先级
	String testPrecondition=null;//测试前提
	String testStep=null;//测试步骤
	String testExcept=null;//预期结果
	public String getTestcasePath() {
		return testcasePath;
	}
	public void setTestcasePath(String testcasePath) {
		this.testcasePath = testcasePath;
	}
	public String getTestcaseName() {
		return testcaseName;
	}
	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}
	public String getTestDescription() {
		return testDescription;
	}
	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}
	public String getTestPriority() {
		return testPriority;
	}
	public void setTestPriority(String testPriority) {
		this.testPriority = testPriority;
	}
	public String getTestPrecondition() {
		return testPrecondition;
	}
	public void setTestPrecondition(String testPrecondition) {
		this.testPrecondition = testPrecondition;
	}
	public String getTestStep() {
		return testStep;
	}
	public void setTestStep(String testStep) {
		this.testStep = testStep;
	}
	public String getTestExcept() {
		return testExcept;
	}
	public void setTestExcept(String testExcept) {
		this.testExcept = testExcept;
	}
	
	public TestCaseBean() {
	
	}

}
