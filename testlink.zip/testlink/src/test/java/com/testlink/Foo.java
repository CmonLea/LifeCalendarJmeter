package com.testlink;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class Foo {

	public static Document createDocument() {
		Document document = DocumentHelper.createDocument();
		Element root = document.addElement("root");

		Element author1 = root.addElement("author").addAttribute("name", "James").addAttribute("location", "UK")
				.addText("James Strachan");

		Element author2 = root.addElement("author").addAttribute("name", "Bob").addAttribute("location", "US")
				.addText("Bob McWhirter");

		return document;
	}

	public static void main(String[] args) throws DocumentException {
		try {
			FileWriter out = new FileWriter("foo.xml");
			Document document = createDocument();
			document.write(out);
			bar(document);
			out.close();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	
	}

	public static void bar(Document document) throws DocumentException {

		Element root = document.getRootElement();

		// iterate through child elements of root
		for (Iterator<Element> it = root.elementIterator(); it.hasNext();) {
			Element element = it.next();
			// do something
			System.out.println(element.getName());
			System.out.println(element.getStringValue());

		}

		// iterate through child elements of root with element name "foo"
		for (Iterator<Element> it = root.elementIterator("foo"); it.hasNext();) {
			Element foo = it.next();
			// do something
		}

		// iterate through attributes of root
		for (Iterator<Attribute> it = root.attributeIterator(); it.hasNext();) {
			Attribute attribute = it.next();
			// do something
		}
	}

}