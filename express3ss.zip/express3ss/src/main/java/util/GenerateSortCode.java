package util;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

public class GenerateSortCode {

	private static String fileOutPutFordler;

	public String getFileFordler() {
		return fileOutPutFordler;
	}

	public static void setFileFordler(String fileFordler) {
		fileOutPutFordler = fileFordler;
	}

	public static String getFileName() {
		return fileName;
	}

	public static void setFileName(String fileName) {
		GenerateSortCode.fileName = fileName;
	}

	private static String fileName;

	public static void createQRCode(String inputString, String fileName, String sortDirectory) {

		int BARCODE_WIDTH = 360;
		int BARCODE_HEIGHT = 180;
		String format = "png";
		Pattern pattern = Pattern.compile("[\\s\\\\/:\\*\\?\\\"<>\\|]");// 匹配文件命名中的特殊字符
		Matcher matcher = pattern.matcher(fileName);

		Hashtable hints = new Hashtable();
		hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
		BitMatrix bitMatrix = null;
		try {

			bitMatrix = new MultiFormatWriter().encode(inputString, BarcodeFormat.CODE_128, BARCODE_WIDTH,
					BARCODE_HEIGHT, hints);

		} catch (WriterException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		File outputDirectory = new File(sortDirectory);
		String ouPutFileFordler = outputDirectory.getAbsolutePath();
		System.out.println("===============文件输出路径为==============" + ouPutFileFordler);
		setFileFordler(ouPutFileFordler);

		if (!outputDirectory.exists()) {
			outputDirectory.mkdir();

		}
		File outputFile = null;

		outputFile = new File(outputDirectory, fileName + ".png");

		try {
			MatrixToImageWriter.writeToFile(bitMatrix, format, outputFile);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}
