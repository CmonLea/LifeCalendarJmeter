package util;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import ui.BatchProduceSortCodeUI;
import ui.ExceptionDialog;

public
class Read2DBFile {



	/**
	 *
	 * @param dbFileURL
	 *            连接的DBURL
	 * @param sheet2Read
	 *            要读取的表名
	 * @throws ClassNotFoundException
	 */
	public static void sqliteConnect(String dbFileURL, String sheet2Read, String sortType)
			throws ClassNotFoundException {
		// 使用当前类的classLoader 加载 sqlite-JDBC driver
		Class.forName("org.sqlite.JDBC");

		Connection connection = null;
		try {
			// 建立数据库连接
			connection = DriverManager.getConnection("jdbc:sqlite:" + dbFileURL);
			Statement statement = connection.createStatement();

			statement.setQueryTimeout(30); // 设置超时为30s.

			ResultSet rs = null;


			int rowCount = 1000;


			// 跳转到要读取的表
			switch (sheet2Read) {

			case "TB01":
				rs = statement.executeQuery("select * from BILL_DES_TB01");

				break;

			case "TB02":
				rs = statement.executeQuery("select * from BILL_DES_TB02");

				break;

			default:
				rs = statement.executeQuery("select * from BILL_DES_TB");

				break;
			}

			while (rs.next()) {
				// 分拣类型为出港
				if (sortType.equals("CG")) {

					// 读取结果集
					String bill_no = null;
					bill_no = rs.getString("BILL_NO");
					System.out.println("============================转换前=======================");
					System.out.println("BILL_NO = " + rs.getString("BILL_NO"));
					System.out.println("DES = " + rs.getString("DES"));
					System.out.println("============================转换前=======================");
					String destination = rs.getString("DES");

					System.out.println("识别的流向为:" + destination);
					String handleDES = ExcepetionScheme.exceptionMatch(destination);// 兜底后的时效和流向
					System.out.println("============================转换后=======================");
					System.out.println("BILL_NO = " + rs.getString("BILL_NO"));
					System.out.println("DES = " + handleDES);
					System.out.println("============================转换后=======================");
					// BatchProduceSortCodeUI batchProduceSortCodeUI =new BatchProduceSortCodeUI();
					List<String> querySortList = BatchProduceSortCodeUI.getQueriedSortList();

					// 如果分拣计划list中包含兜底后的流向则生成条形码
					if (querySortList.contains(handleDES)) {
						System.out.println("当前运单在分拣计划中,正在生成条码");
						GenerateSortCode.createQRCode(bill_no, bill_no, "3S条形码");
						rowCount--;
					}
				}
				// 分拣类型为进港
				if (sortType.equals("JG")) {
					// 读取结果集
					String bill_no = null;
					bill_no = rs.getString("BILL_NO");

					System.out.println("BILL_NO = " + rs.getString("BILL_NO"));
					System.out.println("DES = " + rs.getString("DES"));

					String destination = rs.getString("DES");

					System.out.println("识别的流向为:" + destination);

					// 获得分拣计划
					List<String> querySortList = BatchProduceSortCodeUI.getQueriedSortList();

					// 如果分拣计划list中包含进港的流向则生成条形码
					if (querySortList.contains(destination)) {
						System.out.println("当前运单在分拣计划中,正在生成条码");
						GenerateSortCode.createQRCode(bill_no, bill_no, "3S条形码");
						rowCount--;
					}
				}


				if (rowCount == 0) {

				    new ExceptionDialog(null,null,"生成完毕");
					break;
				}
			}
		} catch (SQLException e) {
			// 捕获数据库异常
			System.err.println(e.getMessage());
		} finally {
			try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				// 捕获关闭异常.
				System.err.println(e);
			}
		}
	}


}