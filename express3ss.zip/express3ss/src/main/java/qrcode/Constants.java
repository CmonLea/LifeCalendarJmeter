package qrcode;

public interface Constants {

	// JDBC 驱动名及数据库 URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	// 业务数据库URL
	//static final String TDOP_BUSINESS_DB_URL = "jdbc:mysql://tdop-mp.dbsit.sfdc.com.cn:3306/tdop";
	static final String TDOP_BUSINESS_DB_URL = "jdbc:mysql://localhost:3306/runoob?useSSL=false";
	// 基础数据库URL
	static final String TDOP_BASCI_DB_URL = "jdbc:mysql://tdopbasic-m.dbsit.sfdc.com.cn:3306/tdopbasic";

	// 数据库的用户名与密码，需要根据自己的设置
//	static final String TDOP_BUSINESS_USER = "tdop";
//	static final String TDOP_BUSINESS_PASS = "tdopd2017!21";
//	
	static final String TDOP_BUSINESS_USER = "root";
	static final String TDOP_BUSINESS_PASS = "Test2017";

	static final String TDOP_BASIC_USER = "tdopbasic";
	static final String TDOP_BASIC_PASS = "6rW9M15pXd";
//	// 查询五和小件细分集货的班次,可参数化字段sort_type,post_no
//	String queryLittleSchedule = "select distinct  schedule from tdop_sort_plan  where transit_depot_no = '755WF' "
//			+ "and sort_type = 'CG'" + "and post_no = 'XX'" + "and slice_id = '0'" + "and del_flag = '0';";
//
//	// 查询五和小件细分集货的格口号(岗位号),可参数化字段sort_type,post_no,schedule_type
//	String queryScheduleType = "select distinct  station_no from tdop_sort_plan  where transit_depot_no = '755WF' "
//			+ "and sort_type = 'CG'" + "and post_no = 'XX'" + "and slice_id = '0'" + "and del_flag = '0'"
//			+ "and schedule_type='1';";
//
//	public void querySchedule(String sort_type,String post_no);
//
//	public void queryStationNo(String sort_type, String post_no, String schedule_type);

}
