package ui;

public class Test1 {

	public static void main(String[] args) {
		System.out.println(BatchProduceSortCodeUI.postNoVal);

	}

}
