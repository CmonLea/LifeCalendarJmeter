package test;

import java.util.List;

public class Classes {

    public Classes(String classId, String className, List<User> users) {
		super();
		this.classId = classId;
		this.className = className;
		this.users = users;
	}

	public Classes() {
		// TODO 自动生成的构造函数存根
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	private String classId; // 班级ID

    private String className; // 班级名称

    private List<User> users;

    

}