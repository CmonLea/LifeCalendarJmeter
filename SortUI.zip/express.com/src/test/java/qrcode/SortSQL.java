package qrcode;
//查询班次
public class SortSQL {
	private String querySortScheduleSql;//查询班次
	private String queryStationNoSql;//查询格口号

	private String queryDeviceNoSql;//查询格口号

	public String getQuerySortScheduleSql() {
		return querySortScheduleSql;
	}

	public void setQuerySortScheduleSql(String querySortScheduleSql) {
		this.querySortScheduleSql = querySortScheduleSql;
	}

	public String getQueryStationNoSql() {
		return queryStationNoSql;
	}

	public void setQueryStationNoSql(String queryStationNoSql) {
		this.queryStationNoSql = queryStationNoSql;
	}
	
	public String getQueryDeviceNoSql() {
		return queryDeviceNoSql;
	}

	public void setQueryDeviceNoSql(String queryDeviceNoSql) {
		this.queryDeviceNoSql = queryDeviceNoSql;
	}

   //根据岗位号查询班次
	public SortSQL(String sort_type, String post_no) {
		// 查询五和小件细分集货的班次,可参数化字段sort_type,post_no
		querySortScheduleSql = "select distinct  schedule from tdop_sort_plan  where transit_depot_no = '755WF' "
				+ "and sort_type = "+"'"+sort_type+"'" + " and post_no ="+ "'"+post_no+"'" + " and slice_id = '0'" + "and del_flag = '0';";

	}

	public SortSQL(String sort_type, String post_no, String schedule) {

		// 查询五和小件细分集货的格口号(岗位号),可参数化字段sort_type,post_no,schedule_type
//		queryStationNoSql = "select distinct  station_no from tdop_sort_plan  where transit_depot_no = '755WF' "
//				+ "and sort_type ="+ "'"+sort_type+"'" + "and post_no ="+ "'"+post_no+"'" + "and slice_id = '0'" + "and del_flag = '0'"
//				+ "and schedule_type="+"'"+schedule_type+"';";
	
		queryStationNoSql = "select distinct  station_no from tdop_sort_plan  where transit_depot_no = '755WF' "
				+ "and sort_type ="+ "'"+sort_type+"'" + "and post_no ="+ "'"+post_no+"'" + "and slice_id = '0'" + "and del_flag = '0'"
				+ "and schedule="+"'"+schedule+"';";
	
	}

	public SortSQL(String querykeyWord,String sort_type, String post_no, String schedule) {

		// 查询五和小件细分集货的格口号(岗位号),可参数化字段sort_type,post_no,schedule_type
//		queryStationNoSql = "select distinct  station_no from tdop_sort_plan  where transit_depot_no = '755WF' "
//				+ "and sort_type ="+ "'"+sort_type+"'" + "and post_no ="+ "'"+post_no+"'" + "and slice_id = '0'" + "and del_flag = '0'"
//				+ "and schedule_type="+"'"+schedule_type+"';";
	
		queryDeviceNoSql = "select distinct "+  querykeyWord+" from tdop_sort_plan  where transit_depot_no = '755WF' "
				+ "and sort_type ="+ "'"+sort_type+"'" + "and post_no ="+ "'"+post_no+"'" + "and slice_id = '0'" + "and del_flag = '0'"
				+ "and schedule="+"'"+schedule+"';";
	
	}
}
