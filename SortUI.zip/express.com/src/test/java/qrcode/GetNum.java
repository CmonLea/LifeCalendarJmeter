package qrcode;

import java.util.Random; 
class GetNum {
	/**
     * 获取count个随机数
     * @param count 随机数个数
     * @return
     */
    public static String game(int count){
        StringBuffer sb = new StringBuffer();
        String str = "012345678901";
        Random r = new Random();
        for(int i=0;i<count;i++){
            int num = r.nextInt(str.length());
            sb.append(str.charAt(num));
            str = str.replace((str.charAt(num)+""), "");
        }
        return sb.toString();
    }
    //根据指定长度生成纯数字的随机数
    public static void createData(int length) {
        StringBuilder sb=new StringBuilder();
        Random rand=new Random();
        for(int i=0;i<length;i++)
        {
            sb.append(rand.nextInt(10));
        }
        String data=sb.toString();
        System.out.println(length+" random data: "+data);
    }

    public static void main(String[] args) {

        //System.out.println(game(13));
        System.out.println(System.currentTimeMillis());
    createData(12);
    }
}
