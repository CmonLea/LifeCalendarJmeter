package qrcode;

public class DynamicSQL {
	String transit_depot_no = "755WF";
	String station_no = "1";
	String sort_type;
	String post_no;
	String device_no;
	String schedule_type;
	String sql;
	
	

	public String getSql() {
		return sql;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}

	// String grid_port_no ;
	public DynamicSQL(String transit_depot_no, String station_no, String sort_type, String post_no, String device_no,
			String schedule_type) {

		this.transit_depot_no = transit_depot_no;
		this.station_no = station_no;
		this.sort_type = sort_type;
		this.post_no = post_no;
		this.device_no = device_no;
		this.schedule_type = schedule_type;
		// this.grid_port_no = grid_port_no;
		sql = "select * from tdop_sort_plan where" + " transit_depot_no=" + "'" + transit_depot_no + "'" + " and"
				+ " sort_type=" + "'" + sort_type + "'" + "and" + " post_no=" + "'" + post_no + "'" + " and"
				+ " slice_id='0' and del_flag='0' and " + " device_no=" + "'" + device_no + "'" + " and"
				+ " station_no=" + station_no + " and" + " schedule_type=" + "'" + schedule_type + "'" + ";";

	}

	public DynamicSQL() {

	}

}
