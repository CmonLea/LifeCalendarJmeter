package sql;

import org.junit.Test;

import qrcode.SortSQL;

public class TestSQL {
	GetSQLExcutionResult sq = new GetSQLExcutionResult();
	// 查询班次
	SortSQL ssql = new SortSQL("CG", "XX");
	// 查询岗位
	SortSQL sql = new SortSQL("CG", "XX", "03:31-12:05");

	@Test
	public void test() {
		System.out.println(ssql.getQuerySortScheduleSql());
		String[] str = sq.puroduceSQL(ssql.getQuerySortScheduleSql(), "schedule");
		for (String a : str) {
			System.out.println(a);
		}
		
		
		System.out.println(sql.getQueryStationNoSql());

		String[] str1 = sq.puroduceSQL(sql.getQueryStationNoSql(), "station_no");
		
		// System.out.println(ssql.getQueryStationNoSql());
		for (String a : str1) {
			System.out.println(a);
		}
	}
}
