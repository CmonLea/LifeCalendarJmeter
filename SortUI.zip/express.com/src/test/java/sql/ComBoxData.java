package sql;

import qrcode.SortSQL;
import ui.BatchProduceSortCodeUI;

public class ComBoxData {
	String post_no;// 岗位号
	String sort_type;// 分拣类型
	String schedule;// 班次
	
	
	BatchProduceSortCodeUI bpscu=new BatchProduceSortCodeUI();
	

	//String[] post_no= {"755WF"};
	GetSQLExcutionResult gser=new GetSQLExcutionResult();

	//SortSQL querySortTypeSql=new SortSQL(sort_type, post_no);
	//SortSQL querySortTypeSql=new SortSQL(sort_type, post_no,schedule);
	SortSQL querySortTypeSql=new SortSQL(bpscu.getSort_type(), bpscu.getPost_no());
	SortSQL queryStaionSql=new SortSQL(bpscu.getSort_type(),  bpscu.getPost_no(), bpscu.getSchedule());
	SortSQL queryDeviceNoSql=new SortSQL("device_no",bpscu.getSort_type(),  bpscu.getPost_no(), bpscu.getSchedule());

	String[] sort_schedule=gser.puroduceSQL(querySortTypeSql.getQuerySortScheduleSql(), "schedule");
	String[] station_no=gser.puroduceSQL(queryStaionSql.getQueryStationNoSql(), "station_no");;
	String[] device_no=gser.puroduceSQL(queryDeviceNoSql.getQueryDeviceNoSql(), "device_no");;

//	}
	public String[] getSort_schedule() {
		return sort_schedule;
	}
	public void setSort_schedule(String[] sort_schedule) {
		sort_schedule=gser.puroduceSQL(querySortTypeSql.getQuerySortScheduleSql(), bpscu.getSchedule());
		this.sort_schedule = sort_schedule;
	}
	public String[] getGrid_no() {
		return station_no;
	}
	public void setGrid_no(String[] station_no) {
		station_no=gser.puroduceSQL(querySortTypeSql.getQueryStationNoSql(), bpscu.getSchedule());
		this.station_no = station_no;
	}
	public String[] getDevice_no() {
		return device_no;
	}
	public void setDevice_no(String[] device_no) {
		this.device_no = device_no;
	}
	
	
}
