package sf.express.com;
public class User {
    
    private String account;
    private Integer age;
    
    public User() {
    }
    public User(String account, Integer age) {
        this.account = account;
        this.age = age;
    }


    public String getAccount() {
        return account;
    }
    public void setAccount(String account) {
        this.account = account;
    }
    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }
    
    

}