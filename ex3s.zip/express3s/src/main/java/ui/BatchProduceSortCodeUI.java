package ui;

import javax.swing.*;

import util.DBUtil;
import util.GetSQLExcutionResult;
import util.GetStoreSortPlan;
import util.Read2DBFile;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.File;

public class BatchProduceSortCodeUI extends JFrame  implements ActionListener {
	private static final long serialVersionUID = 1L;
	/**
	 *
	 */
	String[] exDataArray = { "TB" ,"TB01","TB02"};
	String[] transitDpet = { "755WF" };
	String[] postNo = new String[] { "XC", "XX", "DX" };
	String[] sortType = new String[] { "CG", "JG" };

	String post_no;// 岗位号
	String sort_type;// 分拣类型
	String schedule_type;// 班次

	String device_no;// 设备号

	int numbs;// 要生成单个格口的件数

	public int getNumbs() {
		return numbs;
	}

	public void setNumbs(int numbs) {
		this.numbs = numbs;
	}

	public String getSortCodeSql() {
		return sortCodeSql;
	}

	public void setSortCodeSql(String sortCodeSql) {
		this.sortCodeSql = sortCodeSql;
	}

	String sortCodeSql;
	JComboBox<String> jComboBoxDB = new JComboBox<>(exDataArray);// 实例化一个列表框对象,中转场列表
	JComboBox<String> jComboBoxTransitDpet = new JComboBox<>(transitDpet);// 实例化一个列表框对象,中转场列表
	JComboBox<String> jComboBoxPostNo = new JComboBox<>(postNo);// 实例化一个列表框对象,中转场列表
	JComboBox<String> jComboBoxsortType = new JComboBox<>(sortType);// 分拣类型
	JComboBox<String> jComboBoxSchedule = new JComboBox<>();// 分拣班次
	JComboBox<String> jComboBoxDevice = new JComboBox<>();
	//JComboBox<Integer> jComboBoxGeNum = new JComboBox<>(new Integer[] { 1, 5, 10, 20 });
	JLabel dataLabel=new JLabel("选择数据文件");//设置选择数据文件标签
	
	JButton dataButton=new JButton("加载数据文件..",new ImageIcon("images\\Open16.gif"));//设置选择数据按钮
	
	JFileChooser jFileChooser=new JFileChooser();
	
	JLabel exData=new JLabel("选择兜底数据");//设置选择兜底数据标签
	
//	//设置选择兜底数据按钮
//	JRadioButton tb=new JRadioButton("TB");
//	JRadioButton tb01=new JRadioButton("TB01");
//	JRadioButton tb02=new JRadioButton("TB02");
	
	JLabel jLabelTranstiDept = new JLabel("选择中转场码", SwingConstants.LEFT);// 设置中转场选择框提示文字
	JLabel jLabelPostNo = new JLabel("请选择岗位码", SwingConstants.LEFT);//设置Label对齐方式
	JLabel JLabelSortType = new JLabel("选择分拣类型", SwingConstants.LEFT);
	JLabel schduleLabel = new JLabel("选择分拣班次",SwingConstants.LEFT);
	// JLabel jl3 = new JLabel("请选择格 口 号:");
	JLabel deviceLabel = new JLabel("选择分拣柜号",SwingConstants.LEFT);
	
	JButton generateSortCodeButton = new JButton("批量生成分拣码",new ImageIcon("images\\Save16.gif"));//设置按钮图标
	
	String DBFileURL = null;

	// JTextField jTextField = new JTextField();

	public BatchProduceSortCodeUI() {
		
	
		
	
		dataButton.addActionListener(this);

		// 判断选择的什么岗位然后将岗位赋值以动态查询

		jComboBoxPostNo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// TODO 自动生成的方法存根
				// 判断当前是否选择了岗位
				if (jComboBoxPostNo.getSelectedItem() != null) {
					// 获取列表选择的岗位
					String postNo = (String) jComboBoxPostNo.getSelectedItem();
					// 设置当前岗位
					setPost_no(postNo);

					System.out.println("当前选择的岗位为:" + getPost_no());

				}

			}
		});

		// 判断选择的什么分拣类型，然后动态查询分拣计划
		jComboBoxsortType.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (jComboBoxPostNo.getSelectedItem() != null && jComboBoxsortType.getSelectedItem() != null) {
					// 获取当前选择的分拣类型
					String sortType = (String) jComboBoxsortType.getSelectedItem();
					// 设置班次
					setSort_type(sortType);
					System.out.println("当前选择的分拣类型为：" + sort_type);
					// 根据岗位班次获取查询班次的sql
					String sortSql = new DBUtil(sort_type, post_no).getQuerySortScheduleSql();

					// 执行SQL查询
					DBUtil dbu=new DBUtil();
					
					
					
					GetSQLExcutionResult gs =new GetSQLExcutionResult();
					String[] scheduleData = gs.puroduceSQL(sortSql, "schedule");
					try {
						if (scheduleData != null) {
							System.out.println("查询的分拣数据不为空！");
							// 判断是否有残留数据，如果没有则添加数据
							if (jComboBoxSchedule.getItemCount() == 0) {
								for (String data : scheduleData) {
									jComboBoxSchedule.addItem(data);
								}
							} else {
								// 存在残留数据，先清除所有数据再添加
								int length = jComboBoxSchedule.getItemCount();

								if (length != 0) {
									jComboBoxSchedule.removeAllItems();
								}
								// 添加班次数据
								if (jComboBoxSchedule.getItemCount() == 0) {
									for (String data : scheduleData) {
										jComboBoxSchedule.addItem(data);
									}
								}

							}

						} else {
							System.out.println("查询分拣计划为空!");
							// new ExceptionDialog(this,"查询分拣计划为空！");
							// new ExceptionDialog(this,"查询分拣计划为空");

							if (jComboBoxSchedule.getItemCount() != 0) {
								System.out.println("移除前有" + jComboBoxSchedule.getItemCount() + "个班次");
								// int length=jComboBoxSchedule.getItemCount();
								jComboBoxSchedule.removeAllItems();

							}

						}

					} catch (Exception e1) {
						// TODO 自动生成的 catch 块
						e1.printStackTrace();
					}

					System.out.println(sortSql);

				}

			}
		});

		// 判断选择的什么班次然后动态查询柜子
		jComboBoxSchedule.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (jComboBoxPostNo.getSelectedItem() != null && jComboBoxsortType.getSelectedItem() != null
						&& jComboBoxSchedule.getSelectedItem() != null) {

					// 获取分拣班次
					String schedule = (String) jComboBoxSchedule.getSelectedItem();
					// 设置分拣班次
					setSchedule(schedule);

					System.out.println("当前的岗位为:" + post_no + "当前的分拣类型为:" + sort_type + "当前的班次为:" + schedule_type);

					String sortSql = new DBUtil(sort_type, post_no, schedule_type).getQueryDeviceNoSql();

					System.out.println("查询柜子的sql为:" + sortSql);
					// 执行SQL查询柜子编号
					GetSQLExcutionResult gs = new GetSQLExcutionResult();
					String[] deviceNoData = gs.puroduceSQL(sortSql, "device_no");
					try {
						if (deviceNoData != null) {
							System.out.println("查询的分拣数据不为空！");
							// 判断是否有残留数据，如果没有则添加数据
							if (jComboBoxDevice.getItemCount() == 0) {
								for (String data : deviceNoData) {
									jComboBoxDevice.addItem(data);
								}
							} else {
								// 存在残留数据，先清除数据再添加
								int length = jComboBoxDevice.getItemCount();
								System.out.println(jComboBoxDevice.getItemCount());

								// 清除上次分拣计划查询到的残留的柜子
								if (jComboBoxDevice.getItemCount() != 0) {
									jComboBoxDevice.removeAllItems();
								}

								if (jComboBoxDevice.getItemCount() == 0) {
									for (String data : deviceNoData) {
										jComboBoxDevice.addItem(data);
									}
								}

							}

						} else {
							System.out.println("查询分拣计划为空!");

							if (jComboBoxDevice.getItemCount() != 0) {
								System.out.println("移除前有" + jComboBoxDevice.getItemCount() + "个柜子");
								int length = jComboBoxDevice.getItemCount();
								jComboBoxDevice.removeAllItems();

							}

						}

					} catch (Exception e1) {
						// TODO 自动生成的 catch 块
						e1.printStackTrace();
					}

					System.out.println(sortSql);

				}
			}
		});

		jComboBoxDevice.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (jComboBoxPostNo.getSelectedItem() != null && jComboBoxsortType.getSelectedItem() != null
						&& jComboBoxSchedule.getSelectedItem() != null && jComboBoxDevice != null) {

					// 获取分拣班次
					String device = (String) jComboBoxDevice.getSelectedItem();
					// 设置分拣班次
					setDevice_no(device);

					System.out.println("当前的岗位为:" + post_no + "当前的分拣类型为:" + sort_type + "当前的班次为:" + schedule_type
							+ "当前的设备为:" + device);

					// 生成查询柜子分拣计划的sql
					String sortSql = new DBUtil(sort_type, post_no, schedule_type, device_no).getGenerateSortCodeSql();

					System.out.println("生成分拣码的sql为:" + sortSql);
					setSortCodeSql(sortSql);

				}

			}
		});

		// jTextField.setSize(100, 30);
		// jTextField.setText("请输入生成单个格口的件数");
		//jComboBoxGeNum.setSize(100, 30);
		//

		setSize(new Dimension(340, 430));
		setVisible(true);
		//setResizable(false);// 设置不能调整窗口大小
		setTitle("根据分拣计划生成分拣二维码");
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		Container cp = getContentPane();// 获取一个容器
		cp.setLayout(new FlowLayout(FlowLayout.CENTER,0,10));// 将整个容器设置为1行2列的网格布局
		cp.setBackground(Color.WHITE);

	    JPanel jpanel = new JPanel(new GridLayout(7, 2, 25, 25));// 初始化一个面板设置为4行1列
	    
		jpanel.setBackground(Color.WHITE);
	   // jpanel.setBorder(BorderFactory.createTitledBorder("分组框")); //设置面板边框，实现分组框的效果，此句代码为关键代码

	    jpanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));//设置面板边框颜色

		// 批量生产分拣码按钮
	
		generateSortCodeButton.setBounds(0, 0, 20, 10);// 设置按钮大小
		
		// JButton savePostCodeButton = new JButton("保存岗位码");
		// 单击按钮请求接口生成二维码

		generateSortCodeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				// String text = jTextField.getText();
				//int numbs = (Integer) jComboBoxGeNum.getSelectedItem();
				if (numbs != 0) {
					setNumbs(numbs);
				}
				// System.out.println("text的值为:" + text);
				// if (text != null) {
				// int extext = Integer.parseInt(text);//将字符串转换为int
				// // System.out.println("=======转换后的的extext值为=============:"+extext);
				//
				// setNumbs(extext);
				// } else {
				// System.out.println("没有获取到输入...");
				// }
				// 生成分拣码
				//
				GetStoreSortPlan getStoreSortPlan = new GetStoreSortPlan();

				getStoreSortPlan.getSortQRCode(sortCodeSql, sort_type, numbs);
			}

		});


	
		
		//添加选择数据标签及按钮
		jpanel.add(dataLabel);
		jpanel.add(dataButton);
		
		jpanel.add(exData);
		jpanel.add(jComboBoxDB);
		
		//添加中转场
		jpanel.add(jLabelTranstiDept);
		jpanel.add(jComboBoxTransitDpet);

		//添加岗位
		jpanel.add(jLabelPostNo);
		jpanel.add(jComboBoxPostNo);

		//添加分拣类型
		jpanel.add(JLabelSortType);// 把标签添加到面板
		jpanel.add(jComboBoxsortType);// 把列表框添加到面板

		//添加班次
		jpanel.add(schduleLabel);
		jpanel.add(jComboBoxSchedule);


		//添加柜子
		jpanel.add(deviceLabel);
		jpanel.add(jComboBoxDevice);
		// p1.add(jTextField);
		//添加生成按钮和数量
		//jpanel.add(jComboBoxGeNum);
		//jpanel.add(generateSortCodeButton);
		// p1.add(savePostCodeButton);
		cp.add(jpanel);// 将面板添加到容器
		cp.add(generateSortCodeButton);
		
		// cp.add(jScrollPane);

	}

	public String getDevice_no() {
		return device_no;
	}

	public void setDevice_no(String device_no) {
		this.device_no = device_no;
	}

	public String getSort_type() {
		return sort_type;
	}

	public void setSort_type(String sort_type) {
		this.sort_type = sort_type;
	}

	public String getPost_no() {
		return post_no;
	}

	public void setPost_no(String post_no) {
		this.post_no = post_no;

	}

	public String getSchedule() {
		return schedule_type;
	}

	public void setSchedule(String schedule_type) {
		this.schedule_type = schedule_type;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
        //Handle open button action.
        if (e.getSource() == dataButton) {
            int returnVal = jFileChooser.showOpenDialog(BatchProduceSortCodeUI.this);

            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = jFileChooser.getSelectedFile();
                DBFileURL=file.getAbsolutePath();
                System.out.println("数据库的路径为:"+DBFileURL);
//                 try {
//					Read2DBFile.sqliteConnect(DBFileURL);
//				} catch (ClassNotFoundException e1) {
//					// TODO 自动生成的 catch 块
//					e1.printStackTrace();
//				}
            } 
      
        } 
		
	}

}

class MyComboBox extends AbstractListModel<String> implements ComboBoxModel<String>, MutableComboBoxModel<String> {
	/**
	 *
	 */

	private static final long serialVersionUID = 1L;
	String selecteditem = null;
	//String[] test = { "身份证", "军人证", "学生证", "工作证" };
	String[] test = null;

	public MyComboBox(String[] test) {
		this.test = test;
	}

	@Override
	public Object getSelectedItem() {
		return selecteditem;
	}// 获取下拉列表中的项目

	@Override
	public void setSelectedItem(Object item) {
		selecteditem = (String) item;
	}// 设置下拉列表项目

	@Override
	public String getElementAt(int index) {
		return test[index];
	}// 根据索引返回值

	@Override
	public int getSize() {
		return test.length;
	}// 返回下拉列表框中的数目

	public int getIndex() {
		for (int i = 0; i < test.length; i++) {
			if (test[i].equals(getSelectedItem()))
				return i;
		}
		return 0;
	}

	@Override
	public void addElement(String item) {

	}

	@Override
	public void removeElement(Object obj) {

	}

	@Override
	public void insertElementAt(String item, int index) {

	}

	@Override
	public void removeElementAt(int index) {

	}

}

class ButtonStateCatch extends JFrame implements FocusListener {

	@Override
	public void focusGained(FocusEvent e) {

	}

	@Override
	public void focusLost(FocusEvent e) {
		new ExceptionDialog(this, "文件传输完毕");
	}
}
