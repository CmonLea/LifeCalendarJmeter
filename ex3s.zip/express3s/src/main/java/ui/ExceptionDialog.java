package ui;

import util.ListenerUtil;

import javax.swing.*;
import java.awt.*;

public class ExceptionDialog extends JDialog {

    public ExceptionDialog(Frame owner, String title) {
        super(owner, title);
        Container container = getContentPane();//创建一个容器
        String label = "分拣码生成完毕";
        JLabel jLabel = new JLabel(label);
        JButton jButton = new JButton("打开文件路径...");
        jButton.setBounds(0, 0, 20, 10);
        //jButton.setLayout(new FlowLayout());
        //注册按钮监听
        ListenerUtil listenerUtil =new ListenerUtil();
        jButton.addActionListener(listenerUtil);


        // container.setLayout(new FlowLayout(1,10,10));
        JPanel jPanel =new JPanel(new FlowLayout(2,  20, 20));
        jPanel.add(jLabel);
        jPanel.add(jButton);
        //container.setLayout(new GridLayout(1, 2, 20, 20));
        container.add(jPanel);
        //container.add(jButton);
        setBounds(120, 120, 300, 150);
        setResizable(false);// 设置不能调整窗口大小
        setVisible(true);
    }


}