package util;

//匹配兜底规则
public class ExcepetionScheme {
	/**
	 * 
	 * 
	 * 兜底规则+时效代码强制转换规则： 正常快件代码为产品-中转场代码，如:T4-021W 异常情况如下：
	 * 1、当代码识别为产品-城市代码，如：T4-021，将代码默认归集为附件一对应中转场，如：T4-021WG
	 * 2、当代码识别为中转场代码，如：021W,则将代码默认归集为T4产品，如：T4-021W
	 * 3、当代码识别为城市代码，如021，则将当代码默认归集为T4-对应中转场，如：T4-021WG （对应中转场列表，详见附件一）
	 * 4、SSS后台的时效代码强制转换成对应的分拣匹配代码，比如SSS下载为SP4-010W，则分拣计划按照 T4-010W进行识别 时效代码 分拣匹配代码
	 * T4 T4 T6 T6 T801 T8 T15 T4 SP1 T6 T104 T1 T24 T6 T103 T1 SP4 T4 SP6 T6 SP7 T6
	 * T4
	 * 
	 * 
	 * 
	 */
	// private String detination;

	static String normal = "T(1|4|5|6|8|801|15|104|24|103)-\\d{3,4}[A-Z]{1,2}";// 匹配正常的单号T4-021W
	//static String normalSp="SP(1|4|6|7)-\\d{3,4}[A-Z]{1,2}";// 匹配正常的单号T4-021W
	static String rexProduct_city = "T(4|6|8)-\\d{3,4}";// 匹配产品-城市代码T4-021
	static String transitDept = "\\d{3,4}[A-Z] {1,2}";// 匹配中转场021W
	static String cityCode = "\\d{3,4}";// 匹配城市代码021
	static String forceExchange;
	static GetSQLExcutionResult gser = new GetSQLExcutionResult();
    static	String time;

	public static String exceptionMatch(String destination) {

		// 正常格式直接返回
		if (destination.matches(normal) || destination.startsWith("SP1") || destination.startsWith("SP4")
				|| destination.startsWith("SP6") || destination.startsWith("SP7")) {
			// 匹配常规运单
			if (destination.matches(normal)) {

				return destination;
			}
			// 匹配特殊运单
			if (destination.startsWith("SP1") || destination.startsWith("SP4") || destination.startsWith("SP6")
					|| destination.startsWith("SP7")) {

				time = destination.split("-")[0];//拆分出产品类型
				if (time.startsWith("SP1")) {
					time = "T6";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
				if (time.startsWith("SP4")) {
					time = "T4";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
				if (time.startsWith("SP6")) {
					time = "T6";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
				if (time.startsWith("SP7")) {
					time = "T6";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
			}

		}
		// 识别为产品-城市代码
		if (destination.matches(rexProduct_city)) {

			String splitDes = destination.split("-")[1];// 拆出城市代码
			// 查询城市对应中转场代码
			String sql = "select distinct transit_code from tdop_city_transit where city_code=\'" + splitDes + "\';";
			// 获取城市中转场代码
			int arraySize=gser.puroduceSQL(sql, "transit_code").length;
			if(arraySize!=0) {
				
				String transitCode = gser.puroduceSQL(sql, "transit_code")[0];
				destination = destination.split("-")[0] + "-" + transitCode;
			}else {
				System.out.println("未查到兜底方案!");
			}
			// 城市兜底然后再返回
			return destination;

		}
		// 当代码识别为中转场代码
		if (destination.matches(transitDept)) {

			destination = "T4-" + destination;
			return destination;

		}
		// 当识别为城市代码
		if (destination.matches(cityCode)) {
			// 城市代码先进行兜底操作

			// 查询城市中转场代码
			String sql = "select distinct transit_code from tdop_city_transit where city_code=\'" + destination + "\';";
			// 获取城市中转场代码
			destination = gser.puroduceSQL(sql, "transit_code")[0];
			// 执行兜底操作
			destination = "T4-" + destination;
			return destination;

		}
		return destination;

	}

	/**
	 * 时效强制转换
	 * 
	 * @param time
	 *            要转换的时效
	 * @return
	 */
	public static String timeExchange(String time) {
		if (time.equals("T801")) {
			time = "T8";
		}
		if (time.equals("T15")) {
			time = "T4";
		}
		if (time.equals("SP1")) {
			time = "T6";
		}
		if (time.equals("T104")) {
			time = "T1";
		}
		if (time.equals("T24")) {
			time = "T6";
		}

		if (time.equals("T103")) {
			time = "T1";
		}
		if (time.equals("SP4")) {
			time = "T4";
		}
		if (time.equals("SP6")) {
			time = "T6";
		}
		if (time.equals("SP7")) {
			time = "T6";
		}
//		if (time.equals("") || time == null) {
//			time = "T4";
//		}

		return time;

	}

}
