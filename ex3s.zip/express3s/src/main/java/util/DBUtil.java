package util;

public class DBUtil {



	


	String post_no;
	String sort_type;


	private String querySortScheduleSql;//查询班次
	//private String queryStationNoSql;//查询格口号

	private String queryDeviceNoSql;//查询格口号

	public String getGenerateSortCodeSql() {
		return generateSortCodeSql;
	}


	private String generateSortCodeSql;//生成分拣码sql

	public String getQuerySortScheduleSql() {
		return querySortScheduleSql;
	}

	
	public String getQueryDeviceNoSql() {
		return queryDeviceNoSql;
	}



   //根据岗位号查询班次初始化sql
	public DBUtil(String sort_type, String post_no) {
		// 查询五和小件细分集货的班次,可参数化字段sort_type,post_no
		querySortScheduleSql = "select distinct  schedule from tdop_sort_plan  where transit_depot_no = '755WF' "
				+ "and sort_type = "+"'"+sort_type+"'" + " and post_no ="+ "'"+post_no+"'" + " and slice_id = '0'" + "and del_flag = '0';";

	System.out.println(querySortScheduleSql);
	}

	public DBUtil() {
		super();
	}


	public DBUtil(String sort_type, String post_no, String schedule) {

		// 查询五和小件细分集货的格口号(岗位号),可参数化字段sort_type,post_no,schedule_type
		queryDeviceNoSql = "select distinct  device_no from tdop_sort_plan  where transit_depot_no = '755WF' "
				+ "and sort_type ="+ "'"+sort_type+"'" + "and post_no ="+ "'"+post_no+"'" + "and slice_id = '0'" + "and del_flag = '0'"
				+ "and schedule="+"'"+schedule+"';";
		System.out.println(queryDeviceNoSql);

	
	}


	public DBUtil(String sort_type, String post_no, String schedule,String device) {

		// 查询五和小件细分集货的格口号(岗位号),可参数化字段sort_type,post_no,schedule_type
		generateSortCodeSql = "select * from tdop_sort_plan where transit_depot_no='755WF' "+" and"
				+ " sort_type=" + "'" + sort_type + "'" + "and" + " post_no=" + "'" + post_no + "'" + " and"
				+ " slice_id='0' and del_flag='0' and " + " device_no=" + "'" + device + "'"
				+  " and" + " schedule=" + "'" + schedule + "'" + ";";
		System.out.println(generateSortCodeSql);


	}


	
}




