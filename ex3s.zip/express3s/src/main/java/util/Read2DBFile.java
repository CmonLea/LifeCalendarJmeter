package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Read2DBFile {
	static String DBFileURL = "d:\\user\\80002836\\桌面\\1215\\bultransit2.db";
	

	public static void main(String[] args) {
		try {
			sqliteConnect(DBFileURL, "TB");
		} catch (ClassNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	public static void sqliteConnect(String dbFileURL, String sheet2Read) throws ClassNotFoundException {
		// load the sqlite-JDBC driver using the current class loader
		Class.forName("org.sqlite.JDBC");

		Connection connection = null;
		try {
			// create a database connection
			connection = DriverManager.getConnection("jdbc:sqlite:" + DBFileURL);
			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30); // set timeout to 30 sec.

			ResultSet rs = null;
			// 跳转到要读取的表
			switch (sheet2Read) {
			case "TB":
				rs = statement.executeQuery("select * from BILL_DES_TB");
				break;

			case "TB01":
				rs = statement.executeQuery("select * from BILL_DES_TB01");
				break;

			case "TB02":
				rs = statement.executeQuery("select * from BILL_DES_TB02");
				break;

			// default:

			}

			while (rs.next()) {
				// 读取结果集
				System.out.println("============================转换前=======================");
				System.out.println("BILL_NO = " + rs.getString("BILL_NO"));
				System.out.println("DES = " + rs.getString("DES"));
				System.out.println("============================转换前=======================");
				String destination = rs.getString("DES");
				//String normal = "T(1|4|6|8)-\\d{3,4}[A-Z]{1,2}";
				//if()
				String handleDES = ExcepetionScheme.exceptionMatch(destination);
				System.out.println("============================转换后=======================");
				System.out.println("BILL_NO = " + rs.getString("BILL_NO"));
				System.out.println("DES = " + handleDES);
				System.out.println("============================转换后=======================");
				// read the result set

			}
		} catch (SQLException e) {
			// if the error message is "out of memory",
			// it probably means no database file is found
			System.err.println(e.getMessage());
		} finally {
			try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				// connection close failed.
				System.err.println(e);
			}
		}
	}

}