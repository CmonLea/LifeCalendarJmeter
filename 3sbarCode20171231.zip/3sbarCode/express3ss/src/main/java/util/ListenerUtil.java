package util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ListenerUtil implements ActionListener {
	

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("文件路径为:"+new GenerateSortCode().getFileFordler());
        FileUtil.open_directory(new GenerateSortCode().getFileFordler());//打开文件夹
    }
}
