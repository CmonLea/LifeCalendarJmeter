package ui;

import javax.swing.*;

import util.*;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class BatchProduceSortCodeUI extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    /**
     *
     */
    String[] exDataArray = {"TB", "TB01", "TB02"};
    String[] transitDpet = {"755WF"};
    String[] postNo = new String[]{"XC", "XX", "DX"};
    String[] sortType = new String[]{"CG", "JG"};

    String post_no;// 岗位号
    String sort_type;// 分拣类型
    String schedule_type;// 班次

    String device_no;// 设备号

    public String getSortCodeSql() {
        return sortCodeSql;
    }

    public void setSortCodeSql(String sortCodeSql) {
        this.sortCodeSql = sortCodeSql;
    }

    static List<String> queriedSortList = null;

    public static List<String> getQueriedSortList() {
        return queriedSortList;
    }

    public void setQueriedSortList(List<String> queriedSortList) {
        this.queriedSortList = queriedSortList;
    }

    String sortCodeSql;
    JComboBox<String> jComboBoxDB = new JComboBox<>(exDataArray);// 实例化一个列表框对象,中转场列表
    JComboBox<String> jComboBoxTransitDpet = new JComboBox<>(transitDpet);// 实例化一个列表框对象,中转场列表
    JComboBox<String> jComboBoxPostNo = new JComboBox<>(postNo);// 实例化一个列表框对象,中转场列表
    JComboBox<String> jComboBoxsortType = new JComboBox<>(sortType);// 分拣类型
    JComboBox<String> jComboBoxSchedule = new JComboBox<>();// 分拣班次
    JComboBox<String> jComboBoxDevice = new JComboBox<>();

    // JButton exSortButton =new JButton("查询分拣计划");
    JLabel dataLabel = new JLabel("选择数据文件");// 设置选择数据文件标签

    JButton dataButton = new JButton("加载数据文件..", new ImageIcon("images\\Open16.gif"));// 设置选择数据按钮

    JFileChooser jFileChooser = new JFileChooser();

    JLabel exData = new JLabel("选择兜底数据");// 设置选择兜底数据标签
    JButton exInButton = new JButton("批量生成进港条码",new ImageIcon("images\\Save16.gif"));

   // JProgressBar inProBar = new JProgressBar();
    JButton exOutButton = new JButton("批量生成出港条码",new ImageIcon("images\\Save16.gif"));
  //  JProgressBar outProBar = new JProgressBar(0, 1000);


    JLabel jLabelTranstiDept = new JLabel("选择中转场码", SwingConstants.LEFT);// 设置中转场选择框提示文字
    JLabel jLabelPostNo = new JLabel("请选择岗位码", SwingConstants.LEFT);// 设置Label对齐方式
    JLabel JLabelSortType = new JLabel("选择分拣类型", SwingConstants.LEFT);
    JLabel schduleLabel = new JLabel("选择分拣班次", SwingConstants.LEFT);
    JLabel deviceLabel = new JLabel("选择分拣柜号", SwingConstants.LEFT);

    JButton getSortButton = new JButton("查询分拣计划", new ImageIcon("images\\Search.gif"));
    //JButton generateSortCodeButton = new JButton("批量生成3S条码", new ImageIcon("images\\Save16.gif"));// 设置按钮图标

    String DBFileURL = null;

    public String getDBFileURL() {
        return DBFileURL;
    }

    public void setDBFileURL(String dBFileURL) {
        DBFileURL = dBFileURL;
    }

    private String sheet2Read = "TB";// 要读取的数据表,默认读取TB表
    // 获取要读取的数据表

    public String getSheet2Read() {
        return sheet2Read;
    }

    public String setSheet2Read(String sheet2Read) {
        return this.sheet2Read = sheet2Read;
    }
    // JTextField jTextField = new JTextField();


    public BatchProduceSortCodeUI() {

        dataButton.addActionListener(this);

        // 判断选择的什么岗位然后将岗位赋值以动态查询

        jComboBoxPostNo.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                // TODO 自动生成的方法存根
                // 判断当前是否选择了岗位
                if (jComboBoxPostNo.getSelectedItem() != null) {
                    // 获取列表选择的岗位
                    String postNo = (String) jComboBoxPostNo.getSelectedItem();
                    // 设置当前岗位
                    setPost_no(postNo);

                    System.out.println("当前选择的岗位为:" + getPost_no());

                }

            }
        });

        // 判断选择的什么分拣类型，然后动态查询分拣计划
        jComboBoxsortType.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (jComboBoxPostNo.getSelectedItem() != null && jComboBoxsortType.getSelectedItem() != null) {
                    // 获取当前选择的分拣类型
                    String sortType = (String) jComboBoxsortType.getSelectedItem();
                    // 设置班次
                    setSort_type(sortType);
                    System.out.println("当前选择的分拣类型为：" + sort_type);
                    // 根据岗位班次获取查询班次的sql
                    String sortSql = new DBUtil(sort_type, post_no).getQuerySortScheduleSql();

                    // 执行SQL查询
                    DBUtil dbu = new DBUtil();

                    GetSQLExcutionResult gs = new GetSQLExcutionResult();
                    String[] scheduleData = gs.puroduceSQL(sortSql, "schedule");
                    try {
                        if (scheduleData != null) {
                            System.out.println("查询的分拣数据不为空！");
                            // 判断是否有残留数据，如果没有则添加数据
                            if (jComboBoxSchedule.getItemCount() == 0) {
                                for (String data : scheduleData) {
                                    jComboBoxSchedule.addItem(data);
                                }
                            } else {
                                // 存在残留数据，先清除所有数据再添加
                                int length = jComboBoxSchedule.getItemCount();

                                if (length != 0) {
                                    jComboBoxSchedule.removeAllItems();
                                }
                                // 添加班次数据
                                if (jComboBoxSchedule.getItemCount() == 0) {
                                    for (String data : scheduleData) {
                                        jComboBoxSchedule.addItem(data);
                                    }
                                }

                            }

                        } else {
                            System.out.println("查询分拣计划为空!");
                            // new ExceptionDialog(this,"查询分拣计划为空！");
                            // new ExceptionDialog(this,"查询分拣计划为空");

                            if (jComboBoxSchedule.getItemCount() != 0) {
                                System.out.println("移除前有" + jComboBoxSchedule.getItemCount() + "个班次");
                                // int length=jComboBoxSchedule.getItemCount();
                                jComboBoxSchedule.removeAllItems();

                            }

                        }

                    } catch (Exception e1) {
                        // TODO 自动生成的 catch 块
                        e1.printStackTrace();
                    }

                    System.out.println(sortSql);

                }

            }
        });

        // 判断选择的什么班次然后动态查询柜子
        jComboBoxSchedule.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jComboBoxPostNo.getSelectedItem() != null && jComboBoxsortType.getSelectedItem() != null
                        && jComboBoxSchedule.getSelectedItem() != null) {

                    // 获取分拣班次
                    String schedule = (String) jComboBoxSchedule.getSelectedItem();
                    // 设置分拣班次
                    setSchedule(schedule);

                    System.out.println("当前的岗位为:" + post_no + "当前的分拣类型为:" + sort_type + "当前的班次为:" + schedule_type);

                    String sortSql = new DBUtil(sort_type, post_no, schedule_type).getQueryDeviceNoSql();

                    System.out.println("查询柜子的sql为:" + sortSql);
                    // 执行SQL查询柜子编号
                    GetSQLExcutionResult gs = new GetSQLExcutionResult();
                    String[] deviceNoData = gs.puroduceSQL(sortSql, "device_no");
                    try {
                        if (deviceNoData != null) {
                            System.out.println("查询的分拣数据不为空！");
                            // 判断是否有残留数据，如果没有则添加数据
                            if (jComboBoxDevice.getItemCount() == 0) {
                                for (String data : deviceNoData) {
                                    jComboBoxDevice.addItem(data);
                                }
                            } else {
                                // 存在残留数据，先清除数据再添加
                                int length = jComboBoxDevice.getItemCount();
                                System.out.println(jComboBoxDevice.getItemCount());

                                // 清除上次分拣计划查询到的残留的柜子
                                if (jComboBoxDevice.getItemCount() != 0) {
                                    jComboBoxDevice.removeAllItems();
                                }

                                if (jComboBoxDevice.getItemCount() == 0) {
                                    for (String data : deviceNoData) {
                                        jComboBoxDevice.addItem(data);
                                    }
                                }

                            }

                        } else {
                            System.out.println("查询分拣计划为空!");

                            if (jComboBoxDevice.getItemCount() != 0) {
                                System.out.println("移除前有" + jComboBoxDevice.getItemCount() + "个柜子");
                                int length = jComboBoxDevice.getItemCount();
                                jComboBoxDevice.removeAllItems();

                            }

                        }

                    } catch (Exception e1) {
                        // TODO 自动生成的 catch 块
                        e1.printStackTrace();
                    }

                    System.out.println(sortSql);

                }
            }
        });

        jComboBoxDevice.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jComboBoxPostNo.getSelectedItem() != null && jComboBoxsortType.getSelectedItem() != null
                        && jComboBoxSchedule.getSelectedItem() != null && jComboBoxDevice != null) {

                    // 获取分拣班次
                    String device = (String) jComboBoxDevice.getSelectedItem();
                    // 设置分拣班次
                    setDevice_no(device);

                    System.out.println("当前的岗位为:" + post_no + "当前的分拣类型为:" + sort_type + "当前的班次为:" + schedule_type
                            + "当前的设备为:" + device);

                    // 生成查询柜子分拣计划的sql
                    String sortSql = new DBUtil(sort_type, post_no, schedule_type, device_no).getGenerateSortCodeSql();

                    System.out.println("生成分拣码的sql为:" + sortSql);
                    setSortCodeSql(sortSql);

                    if (sort_type.equals("JG")) {
                        exOutButton.setEnabled(false);//当分拣类型为进港时使出港按钮不可点击
                        exInButton.setEnabled(true);
                    }
                    if (sort_type.equals("CG")) {
                        exInButton.setEnabled(false);//当分拣类型为出港时使进港按钮不可点击
                        exOutButton.setEnabled(true);
                    }


                }

            }
        });

        setSize(new Dimension(650, 400));
        setVisible(true);
        //setResizable(false);// 设置不能调整窗口大小
        setTitle("根据分拣计划生成分拣二维码");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        Container cp = getContentPane();// 获取一个容器
        cp.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));// 将整个容器设置为1行2列的网格布局
        // cp.setLayout(new GridLayout(2,1));
        cp.setBackground(Color.WHITE);

        JPanel jpanel = new JPanel(new GridLayout(6, 2, 25, 25));// 初始化一个面板设置为4行1列
        jpanel.setBackground(Color.WHITE);
        // jpanel.setBorder(BorderFactory.createTitledBorder("分组框"));
        // //设置面板边框，实现分组框的效果，此句代码为关键代码

        jpanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));// 设置面板边框颜色

        JPanel jpanelData = new JPanel(new GridLayout(5, 2, 5, 25));// 初始化一个面板设置为4行1列用来显示兜底相关控件

        // exSortButton.setHorizontalAlignment(SwingConstants.CENTER);

        // JPanel jpanelData = new JPanel(new FlowLayout(SwingConstants.CENTER));//
        // 初始化一个面板设置为4行1列用来显示兜底相关控件
        jpanelData.setPreferredSize(new Dimension(300, 230));

        jpanelData.setBackground(Color.WHITE);// 设置背景色为白色
        jpanelData.setBorder(BorderFactory.createLineBorder(Color.GRAY));// 设置面板边框颜色

        dataLabel.setHorizontalAlignment(SwingConstants.CENTER);
        exData.setHorizontalAlignment(SwingConstants.CENTER);

        dataButton.setPreferredSize(new Dimension(140, 25));

        jComboBoxDB.setPreferredSize(new Dimension(140, 25));// 设置combox的大小

        // 单击按钮请求接口生成3S条码
        getSortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                System.out.println("==============================" + getSortCodeSql());
                String sortPlanQuerySql = getSortCodeSql();
                GetStoreSortPlan getStoreSortPlan = new GetStoreSortPlan();
                queriedSortList = getStoreSortPlan.getSort3SCode(sortPlanQuerySql);
                setQueriedSortList(queriedSortList);// 将分拣计划存储到新的list对象中
                System.out.println("总共有:" + queriedSortList.size() + "条分拣计划");
                for (int i = 0; i < queriedSortList.size(); i++) {
                    System.out.println("查询到的分拣计划为:" + queriedSortList.get(i));
                }

            }

        });

        // 点击"执行进港兜底"按钮执行的逻辑
        exInButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                //exInButton.setText("正在生成...");
                // // TODO 自动生成的方法存根
                try {
                    System.out.println(DBFileURL);
                    System.out.println(sheet2Read);
                    Read2DBFile.sqliteConnect(DBFileURL, sheet2Read, "JG");
                } catch (ClassNotFoundException e1) {
                    // TODO 自动生成的 catch 块
                    e1.printStackTrace();
                }
            }


        });


        // 点击"执行出港兜底"按钮执行的逻辑
        exOutButton.addActionListener(this);




        // 添加选择数据标签及按钮
        jpanelData.add(dataLabel);
        jpanelData.add(dataButton);

        jpanelData.add(exData);
        jpanelData.add(jComboBoxDB);

        jpanelData.add(exInButton);
        //jpanelData.add(inProBar);
        jpanelData.add(exOutButton);// 添加执行兜底按钮
        //jpanelData.add(outProBar);
        // 添加中转场
        jpanel.add(jLabelTranstiDept);
        jpanel.add(jComboBoxTransitDpet);

        // 添加岗位
        jpanel.add(jLabelPostNo);
        jpanel.add(jComboBoxPostNo);

        // 添加分拣类型
        jpanel.add(JLabelSortType);// 把标签添加到面板
        jpanel.add(jComboBoxsortType);// 把列表框添加到面板

        // 添加班次
        jpanel.add(schduleLabel);
        jpanel.add(jComboBoxSchedule);

        // 添加柜子
        jpanel.add(deviceLabel);
        jpanel.add(jComboBoxDevice);


        cp.add(jpanel);// 将面板添加到容器
        cp.add(jpanelData);
        cp.add(getSortButton);


    }

    public String getDevice_no() {
        return device_no;
    }

    public void setDevice_no(String device_no) {
        this.device_no = device_no;
    }

    public String getSort_type() {
        return sort_type;
    }

    public void setSort_type(String sort_type) {
        this.sort_type = sort_type;
    }

    public String getPost_no() {
        return post_no;
    }

    public void setPost_no(String post_no) {
        this.post_no = post_no;

    }

    public String getSchedule() {
        return schedule_type;
    }

    public void setSchedule(String schedule_type) {
        this.schedule_type = schedule_type;
    }

    // 加载数据文件时获取db文件的路径
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle open button action.
        if (e.getSource() == dataButton) {
            int returnVal = jFileChooser.showOpenDialog(BatchProduceSortCodeUI.this);

            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = jFileChooser.getSelectedFile();
                DBFileURL = file.getAbsolutePath();

                System.out.println("数据库的路径为:" + DBFileURL);
                setDBFileURL(DBFileURL);// 设置读取的DBurl

                jComboBoxDB.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (jComboBoxDB.getSelectedItem() != null) {
                            String selectedItem = (String) jComboBoxDB.getSelectedItem();
                            String sheet2Read = setSheet2Read(selectedItem);// 设置读取的表

                            setSheet2Read(sheet2Read);// 设置读取的表
                            // try {
                            // //读取数据
                            // Read2DBFile.sqliteConnect(DBFileURL, sheet2Read);
                            // } catch (ClassNotFoundException e1) {
                            // // TODO 自动生成的 catch 块
                            // e1.printStackTrace();
                            // }
                        }

                    }
                });

            }

        }
        if (e.getSource() == exOutButton) {

            try {
                System.out.println(DBFileURL);
                System.out.println(sheet2Read);

                Read2DBFile.sqliteConnect(DBFileURL, sheet2Read, "CG");

            } catch (ClassNotFoundException e1) {
                // TODO 自动生成的 catch 块
                e1.printStackTrace();
            }
        }

    }


}

class MyComboBox extends AbstractListModel<String> implements ComboBoxModel<String>, MutableComboBoxModel<String> {
    /**
     *
     */

    private static final long serialVersionUID = 1L;
    String selecteditem = null;

    String[] test = null;

    public MyComboBox(String[] test) {
        this.test = test;
    }

    @Override
    public Object getSelectedItem() {
        return selecteditem;
    }// 获取下拉列表中的项目

    @Override
    public void setSelectedItem(Object item) {
        selecteditem = (String) item;
    }// 设置下拉列表项目

    @Override
    public String getElementAt(int index) {
        return test[index];
    }// 根据索引返回值

    @Override
    public int getSize() {
        return test.length;
    }// 返回下拉列表框中的数目

    public int getIndex() {
        for (int i = 0; i < test.length; i++) {
            if (test[i].equals(getSelectedItem()))
                return i;
        }
        return 0;
    }

    @Override
    public void addElement(String item) {

    }

    @Override
    public void removeElement(Object obj) {

    }

    @Override
    public void insertElementAt(String item, int index) {

    }

    @Override
    public void removeElementAt(int index) {

    }

}

//class ButtonStateCatch extends JFrame implements FocusListener {
//
//    @Override
//    public void focusGained(FocusEvent e) {
//
//    }
//
//    @Override
//    public void focusLost(FocusEvent e) {
//        new ExceptionDialog(this, "文件传输完毕");
//    }
//}
