package ui;



public class InstanceUI {

	public static void main(String[] args) {
		new BatchProduceSortCodeUI();
	}

}
