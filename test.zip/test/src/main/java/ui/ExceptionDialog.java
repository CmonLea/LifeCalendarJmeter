package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExceptionDialog extends JDialog {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6610043349809572836L;

	public ExceptionDialog(Frame owner, String title) {
        super(owner, title);
        Container container = getContentPane();//创建一个容器
        String label = "输入不能为空！";
        JLabel jLabel = new JLabel(label);
        jLabel.setOpaque(true);//设置JLabel为透明
        jLabel.setBackground(Color.WHITE);//设置JLabel的填充色为白色
        jLabel.setHorizontalAlignment(SwingConstants.CENTER);
        JButton  jButton=new JButton("确认");
        //jButton.setLayout(new FlowLayout());
        //注册按钮监听
        jButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);//使弹框消失
				
				
			}
		});
      
      

       container.setLayout(new FlowLayout(1,10,10));
        JPanel jPanel =new JPanel(new FlowLayout(1,  20, 20));//设置提示文字居中显示
        jPanel.setBackground(Color.WHITE);//将面板颜色设置为白色
        jPanel.add(jLabel);
       
        //container.setLayout(new GridLayout(1, 2, 20, 20));
        container.add(jPanel);
        container.add(jButton);
        container.setBackground(Color.WHITE);
        setBounds(120, 120, 300, 150);
        setResizable(false);// 设置不能调整窗口大小
        setVisible(true);
    }

    public ExceptionDialog() {
       
    }

}