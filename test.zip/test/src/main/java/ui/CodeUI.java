package ui;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;

import sf.test.GenerateSortCode;

public class CodeUI extends JFrame {
	String inputBarcode;// 输入的条码号

	public String getInputBarcode() {
		return inputBarcode;
	}

	public void setInputBarcode(String inputBarcode) {
		this.inputBarcode = inputBarcode;
	}

	public static void main(String[] args) {
		new CodeUI();
	}

	public CodeUI() {
		Container container = getContentPane(); // 创建一个容器
		container.setBackground(Color.WHITE);// 设置容器背景色为白色

		container.setLayout(new GridLayout(4, 1, 0, 0));// 设置JFrame的布局方式为网格布局
		JPanel jpanel = new JPanel();

		jpanel.setBackground(Color.WHITE);//设置面板的颜色为白色

		/**
		 * 生成条形码控件
		 */
		JLabel jlabel = new JLabel("请输入条码号");
		final JTextField jTextField = new JTextField(15);// 设置JTextField文本框的宽度

		jTextField.setForeground(Color.GRAY);// 设置字体颜色
		final MyCanvasUI mc = new MyCanvasUI();// 创建一个展示图片的实例
		mc.setVisible(false);// 设置初始状态图片不可见

		JButton barCodeButton = new JButton("生成条形码");
		
		final JLabel barCodeText = new JLabel();

		barCodeText.setHorizontalAlignment(SwingConstants.CENTER);// 设置标签文字为居中对齐
//		/**
//		 * 生成二维码控件
//		 */
//	    JLabel rCodeLabel=new JLabel("生成二维码");//生成二维码标签	
//		final JTextArea rCodeText=new JTextArea("请输入文字内容",5,30);
//		rCodeText.setLineWrap(true); //激活自动换行功能 
//		rCodeText.setWrapStyleWord(true);// 激活断行不断字功能
//		rCodeText.setOpaque(false);
//		rCodeText.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));//设置JTextArea边框颜色
//		JButton rCodeButton = new JButton("生成二维码");
//		rCodeButton.setBounds(new Rectangle(50,50));
//		//rCodeButton.setBorderPainted(false);//去掉边框
//		JPanel rCodePanel=new JPanel();
//		rCodePanel.setAlignmentY(LEFT_ALIGNMENT);
//		rCodePanel.setBackground(Color.WHITE);
//		//rCodeText.setSize(150, 30);
//		rCodePanel.add(rCodeLabel);
//		rCodePanel.add(rCodeText);
//		rCodePanel.add(rCodeButton);
		

		// 为按钮设置监听器
		barCodeButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String inPutStr = null;

				inPutStr = jTextField.getText();

				if (!inPutStr.isEmpty()) {

					System.out.println("输入的字符串为:" + inPutStr);
					final String inputStr = jTextField.getText();// 获取文本框输入文本
					setInputBarcode(inputStr);// 将文本取出来
					barCodeText.setText(inputStr);

					System.out.println("条码的内容为:" + getInputBarcode());
					barCodeText.repaint();

					GenerateSortCode.createQRCode(inPutStr, inPutStr, "条形码", "条形码");
					Image image = Toolkit.getDefaultToolkit().getImage("条形码/" + inPutStr + ".png");
					// mc.setSize(360, 160);
					mc.setImage(image);
					mc.repaint();// 刷新图片
					mc.setVisible(true);
					
				} else {
					System.out.println("输入不能为空！");
					new ExceptionDialog(null, null);
					
					
				}

			}
		});
		

		
		
		jpanel.setLayout(new FlowLayout(FlowLayout.CENTER));// 设置面板为流式布局
		jpanel.add(jlabel);// 将标签添加到面板
		jpanel.add(jTextField);// 将文本框添加到面板
		jpanel.add(barCodeButton);// 将按钮添加到面板

		container.add(jpanel);// 将面板添加到容器

		container.add(mc);// 将绘图区域添加到面板
		container.add(barCodeText);
		
		//container.add(rCodeButton);
//		container.add(rCodePanel);

		setSize(400, 450);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);// 设置窗体关闭方式
		setVisible(true);// 使窗体可见
	    setResizable(false);// 设置尺寸不可调整
	}
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -4279063344242268235L;

}

/**
 * 显示图片类
 * 
 */
class MyCanvasUI extends Canvas {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Image in;
//	private int image_width;
//	private int image_height;

	public void setImage(Image in) {
		this.in = in;
	}

	@Override
	public void paint(Graphics g) {
		g.drawImage(in, 0, 0, this.getWidth(), this.getHeight(), this);// 图片大小随窗口调整而调整
		
	}
}
