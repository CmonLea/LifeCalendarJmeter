package sf.test;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

public class GenerateSortCode {
	
	private static String fileOutPutFordler;

	public String getFileFordler() {
		return fileOutPutFordler;
	}

	public static void setFileFordler(String fileFordler) {
		fileOutPutFordler = fileFordler;
	}

//	public static void main(String[] args) {
//		createQRCode("948739979101", "test", "TEST", "条形码");
//	}

	public static void createQRCode(String inputString, String fileName, String sortDirectory, String codeType) {
		int QRCODE_WIDTH = 280;
		int QRCODE_HEIGHT = 280;
		int BARCODE_WIDTH = 360;
		int BARCODE_HEIGHT = 180;
		String format = "png";

		Hashtable hints = new Hashtable();
		hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
		BitMatrix bitMatrix = null;
		try {
			switch (codeType) {
			case "条形码":
				bitMatrix = new MultiFormatWriter().encode(inputString, BarcodeFormat.CODE_128, BARCODE_WIDTH,
						BARCODE_HEIGHT, hints);
				break;

			case "二维码":
				bitMatrix = new MultiFormatWriter().encode(inputString, BarcodeFormat.QR_CODE, QRCODE_WIDTH,
						QRCODE_HEIGHT, hints);
				break;

			}

		} catch (WriterException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		File outputDirectory = new File(sortDirectory);
		String ouPutFileFordler = outputDirectory.getAbsolutePath();
		System.out.println("===============文件输出路径为==============" + ouPutFileFordler);
		setFileFordler(ouPutFileFordler);

		if (!outputDirectory.exists()) {
			outputDirectory.mkdir();

		}
		File outputFile = new File(outputDirectory, fileName + ".png");
		try {
			MatrixToImageWriter.writeToFile(bitMatrix, format, outputFile);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}
