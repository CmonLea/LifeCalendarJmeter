package sf.express.com;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class FreemarkerTest{
    
    FreemarkerUtil fu = null;
    
    @Before
    public void init(){
        if(fu==null){
            fu = new FreemarkerUtil();
        }
    }
    
    @Test
    public void testPrint2Console(){
        //1.创建数据模型
        Map<String, Object> root = new HashMap<String, Object>();
        //2.赋值
        root.put("user_name", "胖先生");
        //3.将数据模型和模版进行结合输出到控制台显示
        fu.print("demo.ftl", root);
        
        
    }
    
    @Test
    public void exportHtml() {
        // 1.创建数据模型
        Map<String, Object> root = new HashMap<String, Object>();
        // 2.赋值
        root.put("user_name", "胖先生");
        //传递数据之一个对象
        root.put("user", new User("四胖子",18));
        //传递一个结合显示
        List<User> userList = Arrays.asList(new User("1号胖子",19),new User("2号胖子",30),new User("3号胖子",50));
        root.put("userList", userList);
        // 3.生成HTML文件
        fu.exportHtml("demo2.ftl", root, "哈哈.html");
    }
}