package sf.express.com;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

public class FreemarkerUtil {

	public Template getTemplate(String name) {

		// 通过Freemarker的Configuration读取相应的ftl
		Configuration configuration = new Configuration(Configuration.VERSION_2_3_23);// 这里是对应的你使用jar包的版本号：<version>2.3.23</version>

		// configuration.setDirectoryForTemplateLoading(new File("/ftl"));
		// //如果是maven项目可以使用这种方式
		configuration.setClassForTemplateLoading(this.getClass(), "template");

		Template template = null;
		try {
			template = configuration.getTemplate(name);
		} catch (TemplateNotFoundException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (MalformedTemplateNameException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		return template;

	}

	public void print(String name, Map<String, Object> root) {
		// 通过Template可以将模版文件输出到相应的文件流
		Template template = this.getTemplate(name);
		try {
			template.process(root, new PrintWriter(System.out));// 在控制台输出内容
		} catch (TemplateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * 到处HTML静态文件
	 * 
	 * @param name
	 * @param root
	 * @param outFile
	 */
	public void exportHtml(String name, Map<String, Object> root, String outFile) {
		FileWriter out = null;
		try {
			out = new FileWriter("output/html/" + outFile);
			// 通过Template可以将模版文件输出到相应的文件流
			Template template = this.getTemplate(name);
			template.process(root, out);// 在控制台输出内容
		} catch (TemplateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (out != null)
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

	}
}