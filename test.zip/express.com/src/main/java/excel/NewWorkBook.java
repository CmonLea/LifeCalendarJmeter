package excel;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

public class NewWorkBook {
	@Test
	public void createXlsFile() {
		  Workbook wb = new HSSFWorkbook();
		    FileOutputStream fileOut = null;
			try {
				fileOut = new FileOutputStream("workbook.xls");
				wb.write(fileOut);
				
			} catch (FileNotFoundException e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			}
		    if(fileOut!=null) {
		    	
		    	try {
					fileOut.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
		    }
		    if(wb!=null) {
				try {
					wb.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
	}
  @Test
	public void createXlsxFile() {
		   Workbook wb = new XSSFWorkbook();
		    FileOutputStream fileOut = null;
			try {
				fileOut = new FileOutputStream("workbook.xlsx");
				wb.write(fileOut);
			} catch (FileNotFoundException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			} catch (IOException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			if(fileOut!=null) {
				
				try {
					fileOut.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
			if(wb!=null) {
				try {
					wb.close();
				} catch (IOException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
			}
  }

 
}
