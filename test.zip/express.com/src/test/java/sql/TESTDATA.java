package sql;

public class TESTDATA {
	// 判断选择的什么岗位然后将岗位赋值以动态查询
	String post_no = (String) jc0.getSelectedItem();

	switch (post_no) {
	case "XC":
		setPost_no("XC");
		break;
	case "XX":
		setPost_no("XX");
		break;

	case "DX":
		setPost_no("DX");
		break;

	}

	// 判断选择的什么分拣类型然后将岗位赋值以动态查询
	String sort_type = (String) jc1.getSelectedItem();

	switch (sort_type) {
	case "CG":
		setSort_type("CG");
		break;
	case "JG":
		setSort_type("JG");
		break;

	}

	// 判断选择的什么班次然后将岗位赋值以动态查询
	String schedule = (String) jc2.getSelectedItem();
	setSchedule(schedule);

	// 判断选择的什么格口号然后将岗位赋值以动态查询
	String grid_no = (String) jc3.getSelectedItem();
	setGrid_no(grid_no);

	// 判断选择的什么规则号然后将岗位赋值以动态查询
	String device_no = (String) jc4.getSelectedItem();
	setDevice_no(device_no);
}
