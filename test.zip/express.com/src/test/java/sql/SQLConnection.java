package sql;

import java.sql.*;

import org.junit.Test;

import qrcode.Constants;
import qrcode.DynamicSQL;
import qrcode.GenerateSortCode;

public class SQLConnection  {
	private int device_no;
	private int grid_port_no;

	private int schedule_type;

	private String destination_code;
	private String prescription_type;
	private String waybill;
	ResultSet rs=null;
	
	@Test
	public ResultSet testGetSortQRCode(String DB_DRIVER,String DB_URL,String DB_USER,String DB_PASS,String SQL) {
		Connection conn = null;
		Statement stmt = null;
		try {
			// 注册 JDBC 驱动
			Class.forName(DB_DRIVER);

			// 打开链接
			System.out.println("连接数据库...");
			if (conn == null) {

				conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			}

			// 执行查询
			System.out.println(" 实例化Statement对...");
			if (stmt == null) {

				stmt = conn.createStatement();
			}

			//DynamicSQL storeGoods = new DynamicSQL("755WF", "1", "CG", "XX", "1", "1");

			// DynamicSQL bulkLoad = new DynamicSQL("755WF","1", "JG", "XX", "1", "1");

			 rs = stmt.executeQuery(SQL);

			// ResultSet rs1=stmt.executeQuery(bulkLoad.getSql());
			// 展开结果集数据库
	
			// 完成后关闭
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			// 处理 JDBC 错误
			se.printStackTrace();
		} catch (Exception e) {
			// 处理 Class.forName 错误
			e.printStackTrace();
		} finally {
			// 关闭资源
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return rs;

	}

public void produceSortCode() {
	while (rs.next()) {
		// 通过字段检索
		device_no = rs.getInt("device_no");
		schedule_type = rs.getInt("schedule_type");
		grid_port_no = rs.getInt("grid_port_no");
		destination_code = rs.getString("destination_code");
		prescription_type = rs.getString("prescription_type");
		// new GenerateSortCode();
		for (int i = 0; i < 9; i++) {
        //生成运单号
			waybill = GenerateSortCode.createData(12);
       //生成集货分拣码
			String sortStoreCode = new GenerateSortCode(destination_code, "", "", prescription_type, waybill)
					.getSortCode();
			// 输出数据

			String bulkLoadCode = new GenerateSortCode(destination_code, "", "", prescription_type, waybill)
					.getSortCode();

			System.out.print("柜子号:" + device_no);
			System.out.print(",班 次:" + schedule_type);
			System.out.print(",格口号: " + grid_port_no);
			System.out.print(",目的代码: " + destination_code);
			System.out.print(",时效类型 : " + prescription_type);
			System.out.print(",运单号为：" + waybill + "\n");
			System.out.println(sortStoreCode);
			GenerateSortCode.createQRCode(sortStoreCode,
					device_no + "-" + schedule_type + "-" + Integer.toString(grid_port_no) + "-" + waybill,
					"storeDirectory");
		}
	}
}
}