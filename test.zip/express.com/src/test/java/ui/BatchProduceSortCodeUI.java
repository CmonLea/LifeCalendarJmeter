package ui;

import javax.swing.*;

import sql.ComBoxData;
import sql.GetSQLExcutionResult;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;

public class BatchProduceSortCodeUI extends JFrame {
	/**
	 *
	 */
	String[] transitDpet = { "755WF" };
	String[] sortSchedule;// 班次数据
	String[] gridNo;// 格口号
	String[] deviceNo;// 设备号

	String post_no;// 岗位号

	String sort_type;// 分拣类型
	String schedule;// 班次
	String grid_no;
	String device_no;

	public String getGrid_no() {
		return grid_no;
	}

	public void setGrid_no(String grid_no) {
		this.grid_no = grid_no;
	}

	public String getDevice_no() {
		return device_no;
	}

	public void setDevice_no(String device_no) {
		this.device_no = device_no;
	}

	public String getSort_type() {
		return sort_type;
	}

	public void setSort_type(String sort_type) {
		this.sort_type = sort_type;
	}

	public String getPost_no() {
		return post_no;
	}

	public void setPost_no(String post_no) {
		this.post_no = post_no;

	}

	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	// ComBoxData cbd =new ComBoxData();
	// new String[] { "五和" }
	private static final long serialVersionUID = 1L;
	JComboBox<String> jc = new JComboBox<>(new MyComboBox(transitDpet));// 实例化一个列表框对象,中转场列表
	JComboBox<String> jc0 = new JComboBox<>(new MyComboBox(new String[] { "XC", "XX", "DX" }));// 实例化一个列表框对象,中转场列表
	JComboBox<String> jc1 = new JComboBox<>(new MyComboBox(new String[] { "CG", "JG" }));
	JComboBox<String> jc2 = new JComboBox<>(new MyComboBox(new String[] { "1", "2", "4", "5" }));
	//JComboBox<String> jc2 = null;
	// JComboBox<String> jc3 = new JComboBox<>(new MyComboBox(new String[] { "CG",
	// "JG" }));
	JComboBox<String> jc4 = new JComboBox<>(new MyComboBox(new String[] { "1", "2", "3" }));
	JLabel jl = new JLabel("请选择中   转    场:");// 设置中转场选择框提示文字
	JLabel jl0 = new JLabel("请选择岗        位:");
	JLabel jl1 = new JLabel("请选择分拣类型:");
	JLabel jl2 = new JLabel("请选择班         次:");
	// JLabel jl3 = new JLabel("请选择格 口 号:");
	JLabel jl4 = new JLabel("请选择柜子编号：");

	public BatchProduceSortCodeUI() {

		// 判断选择的什么岗位然后将岗位赋值以动态查询

		jc0.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO 自动生成的方法存根
				if (jc0.getSelectedItem() != null) {
					String postNo = (String) jc0.getSelectedItem();
					// String sortType=(String)jc1.getSelectedItem();
					// post_no = (String) jc0.getSelectedItem();
					setPost_no(postNo);

					// System.out.println(post_no);
					System.out.println(getPost_no());

					new DBUtil().insert(getPost_no());
				}

			}
		});

		jc1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO 自动生成的方法存根
				if (jc1.getSelectedItem() != null) {

					String sortType = (String) jc1.getSelectedItem();

					setSort_type(sortType);

					new DBUtil().insert(getSort_type());
					System.out.println(sort_type);
				String sortSql=	new DBUtil(sortType, post_no).getQuerySortScheduleSql();

				//执行SQL查询
				GetSQLExcutionResult gs=new GetSQLExcutionResult();
				String[] scheduleData=gs.puroduceSQL(sortSql, "schedule");
				jc2= new JComboBox<>(new MyComboBox(scheduleData));
				System.out.println(jc2.getModel());
				//jc2.a
				
				for(String data:scheduleData) {
					jc2.addItem(data);
					
				}
				
				System.out.println(sortSql);
				
				}

			}
		});

		// switch (post_no) {
		// case "XC":
		// setPost_no("XC");
		// break;
		// case "XX":
		// setPost_no("XX");
		// break;
		//
		// case "DX":
		// setPost_no("DX");
		// break;
		//
		// }
		//
		// // 判断选择的什么分拣类型然后将岗位赋值以动态查询
		// String sort_type = (String) jc1.getSelectedItem();
		//
		// switch (sort_type) {
		// case "CG":
		// setSort_type("CG");
		// break;
		// case "JG":
		// setSort_type("JG");
		// break;
		//
		// }
		//
		// // 判断选择的什么班次然后将岗位赋值以动态查询
		// String schedule = (String) jc2.getSelectedItem();
		// setSchedule(schedule);
		//
		// // 判断选择的什么格口号然后将岗位赋值以动态查询
		// String grid_no = (String) jc3.getSelectedItem();
		// setGrid_no(grid_no);
		//
		// // 判断选择的什么规则号然后将岗位赋值以动态查询
		// String device_no = (String) jc4.getSelectedItem();
		// setDevice_no(device_no);

		setSize(new Dimension(500, 500));
		setVisible(true);
		setResizable(false);// 设置不能调整窗口大小
		setTitle("根据分拣计划生成分拣二维码");
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		Container cp = getContentPane();// 获取一个容器
		cp.setLayout(new GridLayout(1, 0, 5, 50));// 将整个容器设置为1行2列的网格布局

		// JPanel p1 = new JPanel(new FlowLayout(0, 5, 25));
		JPanel p1 = new JPanel(new GridLayout(6, 2, 0, 30));// 初始化一个面板设置为4行1列
		// JPanel p2 = new JPanel(new GridLayout(1, 1, 10, 10));
		// JPanel p2 = new JPanel(new FlowLayout(1, 0, 25));
		JPanel p2 = new JPanel(new GridLayout(1, 1, 10, 10));
		// JPanel p3 = new JPanel(new GridLayout(1, 2, 10, 10));
		JPanel p3 = new JPanel(new FlowLayout(0, 5, 75));
		JButton generatePostCodeButton = new JButton("批量生成分拣码");
		generatePostCodeButton.setBounds(0, 0, 20, 10);// 设置按钮大小
		JButton savePostCodeButton = new JButton("保存岗位码");
		// 单击按钮请求接口生成二维码
		generatePostCodeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 获取图片所在URL
				URL url = BatchProduceSortCodeUI.class.getResource("Octocat.png");

			}
		});
		savePostCodeButton.setBounds(20, 20, 20, 10);

		JPanel p4 = new JPanel();
		// JPanel buttonPanel = new JPanel(new FlowLayout(0, 5, 5));
		p1.add(jl);
		p1.add(jc);

		p1.add(jl0);
		p1.add(jc0);

		p1.add(jl1);// 把标签添加到面板
		p1.add(jc1);// 把列表框添加到面板

		p1.add(jl2);
		p1.add(jc2);

		// p1.add(jl3);
		// p1.add(jc3);

		p1.add(jl4);
		p1.add(jc4);

		p1.add(generatePostCodeButton);
		p1.add(savePostCodeButton);
		cp.add(p1);// 将面板添加到容器

		// p2.add(rCodeDisplayArea);
		// cp.add(p2);
		// p1.add(generatePostCodeButton);
		// p1.add(savePostCodeButton);
		// cp.add(p1);

	}

	// public static void main(String[] args) {
	//
	// new BatchProduceSortCodeUI();
	//
	// }
}

class MyComboBox extends AbstractListModel<String> implements ComboBoxModel<String> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	String selecteditem = null;
	String[] test = { "身份证", "军人证", "学生证", "工作证" };

	public MyComboBox(String[] test) {
		this.test = test;
	}

	public Object getSelectedItem() {
		return selecteditem;
	}// 获取下拉列表中的项目

	public void setSelectedItem(Object item) {
		selecteditem = (String) item;
	}// 设置下拉列表项目

	public String getElementAt(int index) {
		return test[index];
	}// 根据索引返回值

	public int getSize() {
		return test.length;
	}// 返回下拉列表框中的数目

	public int getIndex() {
		for (int i = 0; i < test.length; i++) {
			if (test[i].equals(getSelectedItem()))
				return i;
		}
		return 0;
	}
}
