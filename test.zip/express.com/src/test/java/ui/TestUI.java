package ui;

public class TestUI {

	public static void main(String[] args) {
		new BatchProduceSortCodeUI();
	}

}
