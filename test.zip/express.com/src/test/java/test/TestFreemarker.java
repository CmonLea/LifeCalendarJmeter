package test;

import org.junit.Test;

public class TestFreemarker {
//	CreateHtmlByFreemarker chbf =new CreateHtmlByFreemarker();
	
@Test
public void test1() {
	CreateHtmlByFreemarker.createHtmlFromModel();
}
@Test
public void test2() {
	CreateHtmlByFreemarker.createHtmlFromString();
}

@Test
public void test3() {
	CreateHtmlByFreemarker.createHtmlFromStringList();;
}
}
