package qrcode;

public interface SQLQuery {
	// 查询班次
	String queryScheduleType = "select distinct schedule_type from tdop_sort_plan where schedule_type <> '';";
	// 查询设备编号
	String queryDeviceNo = "select distinctT device_no from tdop_sort_plan where device_no <> ''";
}
