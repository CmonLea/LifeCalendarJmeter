package util;

import org.junit.Test;

//匹配兜底规则
public class ExcepetionScheme {
	/**
	 * 
	 * 
	 * 兜底规则+时效代码强制转换规则： 正常快件代码为产品-中转场代码，如:T4-021W 异常情况如下：
	 * 1、当代码识别为产品-城市代码，如：T4-021，将代码默认归集为附件一对应中转场，如：T4-021WG
	 * 2、当代码识别为中转场代码，如：021W,则将代码默认归集为T4产品，如：T4-021W
	 * 3、当代码识别为城市代码，如021，则将当代码默认归集为T4-对应中转场，如：T4-021WG （对应中转场列表，详见附件一）
	 * 4、SSS后台的时效代码强制转换成对应的分拣匹配代码，比如SSS下载为SP4-010W，则分拣计划按照 T4-010W进行识别 时效代码
	 * 分拣匹配代码 T4 T4 T6 T6 T801 T8 T15 T4 SP1 T6 T104 T1 T24 T6 T103 T1 SP4 T4
	 * SP6 T6 SP7 T6 T4
	 * 
	 * 
	 * 
	 */
	// private String detination;

	static String normal = "T(1|4|5|6|8|801|15|104|24|103)-\\d{3,4}[A-Z]{1,2}";// 匹配正常的单号T4-021W
	// static String normalSp="SP(1|4|6|7)-\\d{3,4}[A-Z]{1,2}";// 匹配正常的单号T4-021W
	static String rexProduct_city = "T(4|6|8)-\\d{3,4}";// 匹配产品-城市代码T4-021
	static String transitDept = "\\d{3,4}[A-Z]{1,2}";// 匹配中转场021W
	static String cityCode = "\\d{3,4}";// 匹配城市代码021
	static String forceExchange;
	static GetSQLExcutionResult gser = new GetSQLExcutionResult();
	static String time;

	public static String exceptionMatch(String destination) {

		// 正常格式直接返回
		if (destination.matches(normal) || destination.startsWith("SP1")
				|| destination.startsWith("SP4")
				|| destination.startsWith("SP6")
				|| destination.startsWith("SP7")) {
			// 匹配常规运单
			System.out.println("匹配正常单号...");
			if (destination.matches(normal)) {
				if (destination.startsWith("T801")) {
					destination = "T8-" + destination.split("-")[1];
					return destination;
				}
				if (destination.startsWith("T15")) {
					destination = "T4-" + destination.split("-")[1];
					return destination;
				}
				if (destination.startsWith("T104")) {
					destination = "T1-" + destination.split("-")[1];
					return destination;
				}
				if (destination.startsWith("T24")) {
					destination = "T6-" + destination.split("-")[1];
					return destination;
				}
				if (destination.startsWith("T103")) {
					destination = "T1-" + destination.split("-")[1];
					return destination;
				}

				return destination;
			}
			// 匹配特殊运单
			if (destination.startsWith("SP1") || destination.startsWith("SP4")
					|| destination.startsWith("SP6")
					|| destination.startsWith("SP7")) {
				System.out.println("匹配特殊单号...");
				time = destination.split("-")[0];// 拆分出产品类型
				if (time.startsWith("SP1")) {
					time = "T6";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
				if (time.startsWith("SP4")) {
					time = "T4";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
				if (time.startsWith("SP6")) {
					time = "T6";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
				if (time.startsWith("SP7")) {
					time = "T6";
					destination = time + "-" + destination.split("-")[1];
					return destination;
				}
			}

		}
		// 识别为产品-城市代码
		if (destination.matches(rexProduct_city)) {
			System.out.println("匹配产品-城市代码");

			String splitDes = destination.split("-")[1];// 拆出城市代码
			// 查询城市对应中转场代码
			String sql = "select distinct transit_code from tdop_city_transit where city_code=\'"
					+ splitDes + "\' and del_flag=0;";
			// 获取城市中转场代码
			int arraySize = gser.puroduceSQL(sql, "transit_code").length;
			if (arraySize != 0) {

				String transitCode = gser.puroduceSQL(sql, "transit_code")[0];
				destination = destination.split("-")[0] + "-" + transitCode;
			} else {
				System.out.println("未查到兜底方案!");
			}
			// 城市兜底然后再返回
			return destination;

		}
		// 当代码识别为中转场代码
		if (destination.matches(transitDept)) {
			System.out.println("匹配识别为中转场代码");

			destination = "T4-" + destination;
			return destination;

		}
		// 当识别为城市代码
		if (destination.matches(cityCode)) {
			// 城市代码先进行兜底操作
			System.out.println("识别为城市代码,识别的值为:" + destination);
			// 查询城市中转场代码
			String sql = "select distinct transit_code from tdop_city_transit where city_code=\'"
					+ destination + "\' and del_flag=0 ;";
			// 获取城市中转场代码
			destination = gser.puroduceSQL(sql, "transit_code")[0];
			System.out.println("查询到的城市代码为:" + destination);
			// 执行兜底操作
			destination = "T4-" + destination;
			System.out.println("兜底后的流向为:" + destination);
			return destination;

		}
		return destination;

	}

	/**
	 * T104 T1 T4 T4 T6 T6 T801 T8 T15 T4 T24 T6 T103 T1 SP1 T6 SP4 T4 SP6 T6
	 * SP7 T6 T4
	 */
//	@Test
//	public void test1() {
//		exceptionMatch("755");// 城市
//
//	}

	@Test
	public void test2() {

		exceptionMatch("010W");// 中转场

	}

//	@Test
//	public void test3() {
//
//		exceptionMatch("T1-010W");// 城市和中转场
//
//	}
//
//	@Test
//	public void test4() {
//
//		exceptionMatch("T4-010W");
//
//	}
//
//	@Test
//	public void test5() {
//
//		exceptionMatch("T6-010W");
//
//	}
//
//	@Test
//	public void test6() {
//
//		exceptionMatch("T8-010W");
//
//	}
//
//	@Test
//	public void test7() {
//
//		exceptionMatch("T15-010W");
//
//	}
//
//	@Test
//	public void test8() {
//
//		exceptionMatch("T24-010W");
//
//	}
//
//	@Test
//	public void test9() {
//
//		exceptionMatch("T103-010W");
//
//	}
//
//	@Test
//	public void test10() {
//
//		exceptionMatch("T104-010W");
//
//	}
//
//	@Test
//	public void test11() {
//
//		exceptionMatch("SP1-010W");// 特殊
//
//	}
//
//	@Test
//	public void test12() {
//
//		exceptionMatch("SP4-010W");
//
//	}
//
//	@Test
//	public void test13() {
//
//		exceptionMatch("SP6-010W");
//
//	}
//
//	@Test
//	public void test14() {
//
//		exceptionMatch("SP7-010W");
//
//	}

}
