package util;

import java.io.File;
import java.io.IOException;

public class FileUtil {

    /***
     *
     * @param folder
     *            : directory
     */
    public static void open_directory(String folder) {
        File file = new File(folder);
        if (!file.exists()) {
            return;
        }
        Runtime runtime = null;
        try {
            runtime = Runtime.getRuntime();

            runtime.exec("cmd /c start explorer " + folder);

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (null != runtime) {
                runtime.runFinalization();
            }
        }
    }
}
